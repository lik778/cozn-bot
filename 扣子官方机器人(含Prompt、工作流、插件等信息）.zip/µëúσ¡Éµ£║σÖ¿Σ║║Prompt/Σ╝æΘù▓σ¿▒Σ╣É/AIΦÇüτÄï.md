
## [AI老王](https://www.coze.cn/store/bot/7342401750953066531)
### Prompt
```md

```
### 描述
我是AI老王，擅长文生图，图片解释，讲故事，吟诗作赋，电影讲解，文案修改，翻译计算，致力于喂养最好的资源，生成最合适的方案
### 开场白
你好，我是 AI 助手，很高兴能为你提供帮助。我不仅可以回答各种问题，还可以提供个性化的建议和指导。
### 开场白预置问题
我可以通过什么方式来提高我的技能？;
你有什么关于某个主题的深入见解？;
你能给我一些关于如何更好地处理某个情况的建议吗？
### 插件信息
```json
{
  "7257418203524284472": {
    "description": "根据文本描述生成图像，可指定图像数量和大小。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/byteartist.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=8i%2BnJ5QXS3cEBbes3ELlqjfT35A%3D",
    "id": "7257418203524284472",
    "name": "ByteArtist",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7281560856729501753": {
    "description": "回答用户关于代表URL的图片的问题。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633870903670062_nZPstQdbIb.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=z9GO3Cpe3Fq9xkQ%2FYXpkx51L6i0%3D",
    "id": "7281560856729501753",
    "name": "图片理解",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710086341&x-signature=Y54CmBU%2BpMLWI1fVp8%2FLUhTjh3Y%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7301970294808494089": {
    "description": "持续更新，了解最新的头条新闻和新闻文章。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/news.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=ZF96Dlbfk7%2BorpzCbFji%2F%2BOYW7A%3D",
    "id": "7301970294808494089",
    "name": "头条新闻",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378823247052812": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_plugin_icon.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=LFFIcDZIBdWdxwR0sUOv2DUaSbE%3D",
    "id": "7303378823247052812",
    "name": "LinkReaderPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7309492133709365258": {
    "description": "可以从图片中提取文本信息",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1541945647966444_1702779861752774955_teZUg2TNvo.jpeg?lk3s=cd508e2b&x-expires=1710086341&x-signature=pPJE0bVSpu81axyQaeAzn9GirlY%3D",
    "id": "7309492133709365258",
    "name": "Simple OCR",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7311552079980511258": {
    "description": "帮助用户在 arXiv 中搜索论文",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1621143884923623_1702613915858360138_0HyTwGOvcF.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=qplj9wRtfGyBhFREfcFDUctYMIg%3D",
    "id": "7311552079980511258",
    "name": "arXiv",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7311965634127183909": {
    "description": "根据您提供的文字生成pdf文档",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706673793112792282_Zs4ZsTcwW3.jpeg?lk3s=cd508e2b&x-expires=1710086341&x-signature=hPd7e630v3v4foCunCooGXMy9V8%3D",
    "id": "7311965634127183909",
    "name": "Doc Maker",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7312638848524091418": {
    "description": "给新生儿起名",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1814656427232840_1702623434527914058_bhB4UTugPP.jpeg?lk3s=cd508e2b&x-expires=1710086341&x-signature=%2FNACtJPFFgdGuT49J9PZS65HViY%3D",
    "id": "7312638848524091418",
    "name": "起名",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7319849872859922483": {
    "description": "一个超棒的表情搜索和消息处理插件 # 提供的主要功能： ## EmojiMessage: 将用户输入转换为表情，并推荐可能需要的表情。 ## EmojiTranslation: 将用户输入转换为表情。 ## emojiSearch: 用用户输入搜寻表情包。 ## emojiKitchen: 将两个表情合并为一个表情。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/811914279529784_1704285420067450438_3EpBXpxSr8.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=%2F0VH4SGK8Z9rYuLVPISfcLhX5lk%3D",
    "id": "7319849872859922483",
    "name": "Emojesus",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7320064854835118106": {
    "description": "快递查询",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/4092809514331888_1704335705097682457_Wvpsx00xu5.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=h3WdM8%2FRVl1n6U1pUBsVliOgxiI%3D",
    "id": "7320064854835118106",
    "name": "快递查询助手",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7322789345591787570": {
    "description": "用AI生成音乐",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/987825106064111_1704969834027056593_HwPqV0bq45.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=4tNlFS4u%2Bq%2BaHi6IYM0Og9uPn8A%3D",
    "id": "7322789345591787570",
    "name": "AI乐队",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7325002728516796450": {
    "description": "如果你想要查询汽车信息，包括二手车、新车、某些车型的信息时可以使用此插件进行查询",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/4330337972264831_1706683598008238434_IJxoF3TQZf.jpeg?lk3s=cd508e2b&x-expires=1710086341&x-signature=6dOvJfH%2BqTMMjxlm5lXhFSecoSs%3D",
    "id": "7325002728516796450",
    "name": "懂车帝",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326751620975525939": {
    "description": "根据描述搜索中国诗的详细内容",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1705892801734443723_pUUW7XqCUy.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=knlL%2BqyqilsnBuqzX4gKI%2BckaQE%3D",
    "id": "7326751620975525939",
    "name": "中国诗搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326758047861178394": {
    "description": "告诉你怎样写汉字",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1705894572407908075_OVtg8TWIVw.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=gI923vohA7fmk39nk7SGvNg31kg%3D",
    "id": "7326758047861178394",
    "name": "写汉字",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7338709153852129332": {
    "description": "用来处理需要准确数据计算的场景",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=INRWjgzNEJDseGGPuAo%2F01tqDQg%3D",
    "id": "7338709153852129332",
    "name": "计算器",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340254693152587812": {
    "description": "通过调用接口随机返回一首古诗词",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/926251375927184_1709036244700397289_yXFiEPu4xT.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=AcMOC%2BFvwm20dfHrdj1lji9FGDs%3D",
    "id": "7340254693152587812",
    "name": "今日诗词",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340261121296711715": {
    "description": "获取知乎热榜列表",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/926251375927184_1709037738013817651_0PtcoVZPNv.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=JyYWLRjQUDsRmEGjXy%2FrzDPSjUU%3D",
    "id": "7340261121296711715",
    "name": "知乎热榜",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340942593993261093": {
    "description": "从imdb中获取最新电影预告片信息，包括电影名，预告片链接以及封面链接（python学霸微信公众号）",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=uKv5FTuvYfhzfE7Z%2ByPA4pFzyF0%3D",
    "id": "7340942593993261093",
    "name": "IMDB电影预告片",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340989780584398886": {
    "description": "谷歌翻译助手",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709207395672843926_4UtesgCoqV.jpg?lk3s=cd508e2b&x-expires=1710086341&x-signature=aeRb4PHkErpS00YQ11AgVcRQXP4%3D",
    "id": "7340989780584398886",
    "name": "谷歌翻译助手",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7341300214776774706": {
    "description": "你好！我是一个能为你提供家庭教育相关信息和建议的智能助手。由大湾区亲子教育研究院全面主持。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=INRWjgzNEJDseGGPuAo%2F01tqDQg%3D",
    "id": "7341300214776774706",
    "name": "家庭教育金字塔",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7341313237952167947": {
    "description": "把用户输入的文字转换为语音",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710086341&x-signature=A6%2B3FD%2Bt2Kb8XS3Klf3KDEp5mdE%3D",
    "id": "7341313237952167947",
    "name": "文字转语音",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288245311594610745": {
    "description": "回答用户关于图像的问题",
    "id": "7288245311594610745",
    "name": "imgUnderstand",
    "parameters": [
      {
        "description": "用户关于图片的问题",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图像的URL地址，可以从中下载图像的二进制信息",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281560856729501753"
  },
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7288904268684378171": {
    "description": "通过文字描述生成图片",
    "id": "7288904268684378171",
    "name": "text2image",
    "parameters": [
      {
        "description": "图片高度，必须使用512",
        "is_required": false,
        "name": "height",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "1代表通用风格，0代表动漫风格",
        "is_required": false,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "要生成的图片数量",
        "is_required": false,
        "name": "nums",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用于图片描述，使用多个短语概括实体",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图片宽度，必须使用512",
        "is_required": false,
        "name": "width",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7301970294808510473": {
    "description": "搜索新闻讯息",
    "id": "7301970294808510473",
    "name": "getToutiaoNews",
    "parameters": [
      {
        "description": "搜索新闻的关键词，必须用中文",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7301970294808494089"
  },
  "7303378823247069196": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "id": "7303378823247069196",
    "name": "LinkReaderPlugin",
    "parameters": [
      {
        "description": "当type为“检索”时，需要检索的query",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "插件使用方式。可以是“全文”或者“检索”",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "网页url、pdf url、抖音视频url、docx url、csv url。",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378823247052812"
  },
  "7309492293126635557": {
    "description": "图像URL的光学字符识别",
    "id": "7309492293126635557",
    "name": "ocr",
    "parameters": [
      {
        "description": "图像url地址",
        "is_required": true,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7309492133709365258"
  },
  "7311552228765007922": {
    "description": "帮助用户在arXiv中搜索论文。",
    "id": "7311552228765007922",
    "name": "search",
    "parameters": [
      {
        "description": "使用英文搜索关键词，例如量子力学，基因等",
        "is_required": false,
        "name": "search_query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索数量",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7311552079980511258"
  },
  "7311967093384118310": {
    "description": "从您提供的文本生成PDF。",
    "id": "7311967093384118310",
    "name": "GenPdf",
    "parameters": [
      {
        "description": "pdf内容",
        "is_required": false,
        "name": "content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7311965634127183909"
  },
  "7312643416163139621": {
    "description": "根据命运给出一个合适的名字，用户必须输入性别、出生年月日时、姓氏，当用户给的信息不完善的时候，给用户返回固定的话术：如果想获得名字，需要给我信息的是：我是男性/女性，姓氏，生于xx年xx月xx日xx时。",
    "id": "7312643416163139621",
    "name": "charactor_fate",
    "parameters": [
      {
        "description": "出生日，格式为dd，取值范围为[1,31]，默认值为31",
        "is_required": true,
        "name": "day",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "要被起名的人的性别，取值范围为男或女",
        "is_required": true,
        "name": "gender",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "出生在当天第几个小时，格式为hh，取值范围为[0,24]无用户输入时，默认为00",
        "is_required": true,
        "name": "hour",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "出生月，格式为mm，取值范围为[1,12]，默认值为1",
        "is_required": true,
        "name": "month",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "出生年，格式为yyyy，例如1998，默认值为2024",
        "is_required": true,
        "name": "year",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7312638848524091418"
  },
  "7319850092364693555": {
    "description": "这用于处理用户输入的信息，它将用户输入的信息转换为表情符号，同时在当前消息状态下生成表情符号，并推荐可能需要的表情符号。",
    "id": "7319850092364693555",
    "name": "EmojiMessage",
    "parameters": [
      {
        "description": "用户发送的所有消息或需要为表情符号生成的部分文本。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319850933704507401": {
    "description": "将用户输入的信息翻译成表情符号。",
    "id": "7319850933704507401",
    "name": "EmojiTranslation",
    "parameters": [
      {
        "description": "用户发送的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851399809024010": {
    "description": "根据用户当前的消息搜索对应的表情符号。",
    "id": "7319851399809024010",
    "name": "EmojiSearch",
    "parameters": [
      {
        "description": "用户需要搜索的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "页数，如果没有指定，则输入默认值0。",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851795084525618": {
    "description": " 将用户发送的两个emoji组合成一个emoji。",
    "id": "7319851795084525618",
    "name": "EmojiKitchen",
    "parameters": [
      {
        "description": "用户发送的第一个表情符号。",
        "is_required": false,
        "name": "firstEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户发送的第二个表情符号。",
        "is_required": false,
        "name": "secondEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7320065776042508326": {
    "description": "获取快递信息。",
    "id": "7320065776042508326",
    "name": "get_express_info",
    "parameters": [
      {
        "description": "快递单号",
        "is_required": false,
        "name": "express_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7320064854835118106"
  },
  "7322789404693790771": {
    "description": "根据歌词生成歌曲",
    "id": "7322789404693790771",
    "name": "lyrics_to_song",
    "parameters": [
      {
        "description": "lyrics array",
        "is_required": false,
        "name": "lyrics",
        "sub_parameters": [],
        "sub_type": "",
        "type": "array"
      }
    ],
    "plugin_id": "7322789345591787570"
  },
  "7325002728516812834": {
    "description": "当你查询二手车的售卖信息时候可以使用此工具，可以获得二手车的价格、二手车车况图片等信息",
    "id": "7325002728516812834",
    "name": "SecondHandCar",
    "parameters": [
      {
        "description": "期望查询的汽车品牌，如宝马、奥迪",
        "is_required": false,
        "name": "brand",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询二手车的城市",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的二手车类型、如中型suv、紧凑型轿车等",
        "is_required": false,
        "name": "grade",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询二手车的价格范围",
        "is_required": false,
        "name": "price_tag",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的车系，如宝马1系、奥迪a4等",
        "is_required": false,
        "name": "series",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325002728516796450"
  },
  "7325702773411004425": {
    "description": "当你需要查询新车信息或者查询某个特定车系（如宝马3系，奔驰e级）信息的时候可以使用此工具，可以获得新车价格，车辆结构，车辆生产年份，售卖链接等信息",
    "id": "7325702773411004425",
    "name": "CarSeries",
    "parameters": [
      {
        "description": "期望查询的车系，如宝马3系、奔驰e级",
        "is_required": true,
        "name": "series",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325002728516796450"
  },
  "7326751620975542323": {
    "description": "根据给定条件搜索中国诗",
    "id": "7326751620975542323",
    "name": "search",
    "parameters": [
      {
        "description": "排除的诗词列表",
        "is_required": false,
        "name": "excluded",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "在古代和现代中文中的标签，最多10项。",
        "is_required": false,
        "name": "tags",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "中国诗词的标题",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "中国诗的作者",
        "is_required": false,
        "name": "author",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "返回的诗数量, 小于10",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326751620975525939"
  },
  "7326758047861194778": {
    "description": "为用户创建展示汉字笔顺的gif动画。输入参数必须是中文。",
    "id": "7326758047861194778",
    "name": "create_hanzi_gif",
    "parameters": [
      {
        "description": "创建gif动画所用的汉字必须是一个汉字",
        "is_required": true,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326758047861178394"
  },
  "7329419680601636873": {
    "description": "根据用户的描述生成多种风格的图片\n",
    "id": "7329419680601636873",
    "name": "ImageToolPro",
    "parameters": [
      {
        "description": "图片的链接，在model_type为2的情况下需要传入",
        "is_required": false,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成图片的类型：0代表通用风格、1代表卡通风格、3代表像素贴纸风格、2根据用户输入的图片进行生成",
        "is_required": true,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "对于要生成的图片的描述",
        "is_required": true,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7332032784040525863": {
    "description": "提供新春萌宠图片生成，当用户上传宠物图片或者提供图片链接时，可以用此工具生成新的新春萌宠图片",
    "id": "7332032784040525863",
    "name": "new_year_pets_image",
    "parameters": [
      {
        "description": "图片链接。该字段是必传的",
        "is_required": true,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成的图片的类型模版。宠物礼盒:1 , 新年工笔画:2, 新年唐装:3, 东北大花:4, 情人玫瑰:5, 天使丘比特:6, 恭喜发财:7",
        "is_required": false,
        "name": "model",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "-1代表随机生成。默认29",
        "is_required": false,
        "name": "seed",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "生成的图片质量。0.3:低, 0.5:中, 0.7:高",
        "is_required": false,
        "name": "strength",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7338709383590936617": {
    "description": "使用表达式来获得答案，比如2+2*200, 这个插件会返回正确答案402",
    "id": "7338709383590936617",
    "name": "Math",
    "parameters": [
      {
        "description": "表达式字符串",
        "is_required": true,
        "name": "expr",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "精确度，默认为空",
        "is_required": false,
        "name": "precision",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7338709153852129332"
  },
  "7340237357024739340": {
    "description": "生成csv 或 xlsx 的电子表格。",
    "id": "7340237357024739340",
    "name": "create_spreadsheet",
    "parameters": [
      {
        "description": "csv 格式的内容",
        "is_required": true,
        "name": "csv_content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "标题",
        "is_required": true,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "csv 或 xlsx",
        "is_required": true,
        "name": "to_format",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7311965634127183909"
  },
  "7340237357024755724": {
    "description": "生成 PPT",
    "id": "7340237357024755724",
    "name": "create_pptx",
    "parameters": [
      {
        "description": "PPT 的标题",
        "is_required": true,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "markdown 格式的 PPT 内容",
        "is_required": true,
        "name": "formatted_markdown",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7311965634127183909"
  },
  "7340237357024772108": {
    "description": "生成 pdf, docx, html, markdown, latex 格式的文档。",
    "id": "7340237357024772108",
    "name": "create_document",
    "parameters": [
      {
        "description": "生成文档的格式, 可选值： pdf, docx, html, latex, markdown",
        "is_required": true,
        "name": "to_format",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "Markdown 格式的文档内容",
        "is_required": true,
        "name": "formatted_markdown",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成文档的标题，如果用户没指定则会根据内容生成",
        "is_required": true,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7311965634127183909"
  },
  "7340255333610192905": {
    "description": "每次调用都能够自动获取一首诗词。",
    "id": "7340255333610192905",
    "name": "poetry_generation",
    "parameters": [],
    "plugin_id": "7340254693152587812"
  },
  "7340261376130187318": {
    "description": "获取知乎热榜列表",
    "id": "7340261376130187318",
    "name": "get_hot_list",
    "parameters": [
      {
        "description": "获取数量，默认15条",
        "is_required": false,
        "name": "limit",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340261121296711715"
  },
  "7340468890209861683": {
    "description": "获取推荐列表",
    "id": "7340468890209861683",
    "name": "get_recommend",
    "parameters": [
      {
        "description": "获取数量，默认6",
        "is_required": false,
        "name": "limit",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340261121296711715"
  },
  "7340942949343051776": {
    "description": "从imdb网站获取最新电影预告片信息，包括电影名，预告片链接以及封面链接",
    "id": "7340942949343051776",
    "name": "imdb",
    "parameters": [
      {
        "description": "数量，空为所有",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340942593993261093"
  },
  "7340989903762882579": {
    "description": "谷歌翻译助手",
    "id": "7340989903762882579",
    "name": "google_translate",
    "parameters": [
      {
        "description": "文本",
        "is_required": true,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "源语言",
        "is_required": false,
        "name": "from_lang",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "目标语言",
        "is_required": false,
        "name": "to_lang",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340989780584398886"
  },
  "7341301556891090959": {
    "description": "家庭教育金字塔，成就孩子的未来。\n提供家庭教育中常见问题的解决方案，如孩子的学习问题、行为问题、心理问题等。",
    "id": "7341301556891090959",
    "name": "kidway",
    "parameters": [],
    "plugin_id": "7341300214776774706"
  },
  "7341313546715693066": {
    "description": "获取所有可用的音色列表",
    "id": "7341313546715693066",
    "name": "getSpeakers",
    "parameters": [],
    "plugin_id": "7341313237952167947"
  },
  "7341314066348130340": {
    "description": "将用户输入的文本内容转换为音频",
    "id": "7341314066348130340",
    "name": "getVoice",
    "parameters": [
      {
        "description": "语言",
        "is_required": true,
        "name": "language",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "文本内容",
        "is_required": true,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "音色编号",
        "is_required": true,
        "name": "voice_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7341313237952167947"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
