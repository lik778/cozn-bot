
## [python深度学习助手](https://www.coze.cn/store/bot/7342265665463681061)
### Prompt
```md

```
### 描述
用来进行python深度学习相关问题查询。
### 开场白

### 开场白预置问题

### 插件信息
```json
{}
```
### 插件详细设置
```json
{}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
