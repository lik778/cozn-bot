
## [朱哥的AI助理](https://www.coze.cn/store/bot/7342051457421688858)
### Prompt
```md

```
### 描述
你是一个全能的AI助理，掌握所有中外历史、哲学、焦化/化工知识，熟悉最新的科技进展，特别是在人工智能相关领域信息，能在生活、工作和哲学思考方面提供全方位的帮助。
### 开场白

### 开场白预置问题

### 插件信息
```json
{
  "7288584252030189623": {
    "description": "Bing 图像搜索API允许用户在全球范围内查找图片。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2175268956156697_1709192841685149969_qPefr5tCsS.png?lk3s=cd508e2b&x-expires=1710077087&x-signature=UXZzIMQJo7CCeHyhsjZNkDyapAo%3D",
    "id": "7288584252030189623",
    "name": "必应图片搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710077087&x-signature=EX1oEBIlxQmkkXUuBtb3jTlsU4c%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7301970294808494089": {
    "description": "持续更新，了解最新的头条新闻和新闻文章。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/news.png?lk3s=cd508e2b&x-expires=1710077087&x-signature=V7izm%2BrNIS1sW4O5FvYnxg9152Y%3D",
    "id": "7301970294808494089",
    "name": "头条新闻",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378823247052812": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_plugin_icon.png?lk3s=cd508e2b&x-expires=1710077087&x-signature=wDzu2B3N%2FYrreDjvl2%2B%2FRpuZjpU%3D",
    "id": "7303378823247052812",
    "name": "LinkReaderPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7309832488279638025": {
    "description": "Notion 文档插件通过用户对集成的授权来支持获取用户文档的内容。\n\n插件会缓存用户token一个小时，因此目前变更文档授权范围又需要一个小时。\n目前，插件只能访问文档中最多3层的内容，不能无限制访问嵌套的内容。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/539199853837945_1702472740511698304_Sgw9yQrUiN.png?lk3s=cd508e2b&x-expires=1710077087&x-signature=%2BxSXAlW7TcqedddzZERjo2NUXqc%3D",
    "id": "7309832488279638025",
    "name": "Notion",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7324208543966593074": {
    "description": "WebPilot 与网页交互，提取特定信息或处理URL的内容。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1603551973629358_1705300322286341143_iygfyD6y9O.jpeg?lk3s=cd508e2b&x-expires=1710077087&x-signature=YAMpZxNvZ%2FGnRmJ9uxuYcf4VrKQ%3D",
    "id": "7324208543966593074",
    "name": "WebPilot",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326774526069489701": {
    "description": "天气Plugin。提供省、市、区县的未来40天的天气情况，包括温度、湿度、日夜风向等。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621033925555371_rPUemhsbVg.webp?lk3s=cd508e2b&x-expires=1710077087&x-signature=yxpCRJuE0eQ3YzVF%2FsNY6mR01jc%3D",
    "id": "7326774526069489701",
    "name": "墨迹天气",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7328325109209382949": {
    "description": "在英语环境下可以自动化翻译",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077087&x-signature=gEVstuN7MQUYMU32CNg%2FCYzhKi4%3D",
    "id": "7328325109209382949",
    "name": "翻译",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7336880488105230376": {
    "description": "在线搜索书籍信息",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2553529766254206_1708329393006626645_JbmGmGcC40.png?lk3s=cd508e2b&x-expires=1710077087&x-signature=rWaRmfkJQ8UEWXxkijvbrcW4e5c%3D",
    "id": "7336880488105230376",
    "name": "在线搜书",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288584252030206007": {
    "description": "必应图像搜索API允许您的用户在全球范围内找到图片。",
    "id": "7288584252030206007",
    "name": "bingImageSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从结果中返回前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": true,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288584252030189623"
  },
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7301970294808510473": {
    "description": "搜索新闻讯息",
    "id": "7301970294808510473",
    "name": "getToutiaoNews",
    "parameters": [
      {
        "description": "搜索新闻的关键词，必须用中文",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7301970294808494089"
  },
  "7303378823247069196": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "id": "7303378823247069196",
    "name": "LinkReaderPlugin",
    "parameters": [
      {
        "description": "当type为“检索”时，需要检索的query",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "插件使用方式。可以是“全文”或者“检索”",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "网页url、pdf url、抖音视频url、docx url、csv url。",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378823247052812"
  },
  "7309832648292057114": {
    "description": "获取Notion文件信息",
    "id": "7309832648292057114",
    "name": "get_notion_document_info",
    "parameters": [
      {
        "description": "Notion文档的URL",
        "is_required": false,
        "name": "document_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询Notion块的数量",
        "is_required": false,
        "name": "block_search_size",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309832488279638025"
  },
  "7324208543966609458": {
    "description": "WebPilot 进行互联网搜索、分析以及数据生成。\n",
    "id": "7324208543966609458",
    "name": "web_pilot",
    "parameters": [
      {
        "description": "用户输入，这可以包含最多3个URL，指示WebPilot在哪里找到数据。或者如果没有提供URL，WebPilot将自行查找数据。",
        "is_required": true,
        "name": "content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7324208543966593074"
  },
  "7326770499395239946": {
    "description": "获取指定日期的天气",
    "id": "7326770499395239946",
    "name": "DayWeather",
    "parameters": [
      {
        "description": "市名，包括直辖市，比如：北京市、天津市、上海市、重庆市",
        "is_required": false,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待查询结束日期",
        "is_required": false,
        "name": "end_time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "省份名，不要包括直辖市(比如：北京、北京市、北京省、天津市、上海市、重庆市)",
        "is_required": false,
        "name": "province",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待查询开始日期",
        "is_required": false,
        "name": "start_time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "区/县/镇",
        "is_required": false,
        "name": "towns",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "乡/村",
        "is_required": false,
        "name": "villages",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326774526069489701"
  },
  "7328328040071725082": {
    "description": "在有英语或其他语言输出时，自动切换成中文",
    "id": "7328328040071725082",
    "name": "fanyi_1",
    "parameters": [
      {
        "description": "翻译",
        "is_required": false,
        "name": "fanyi",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当用户提供人名时，不翻译",
        "is_required": true,
        "name": "name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7328325109209382949"
  },
  "7336880753411637258": {
    "description": "在线搜索书籍信息，返回结构化的书籍列表信息",
    "id": "7336880753411637258",
    "name": "search_books_online",
    "parameters": [
      {
        "description": "搜索的关键词，可以是书名、作者名、ISBN 等",
        "is_required": true,
        "name": "kw",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7336887801167904778": {
    "description": "根据唯一 id 获取该书籍相关的详细信息",
    "id": "7336887801167904778",
    "name": "get_online_book_info",
    "parameters": [
      {
        "description": "书籍的唯一 id",
        "is_required": true,
        "name": "id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
