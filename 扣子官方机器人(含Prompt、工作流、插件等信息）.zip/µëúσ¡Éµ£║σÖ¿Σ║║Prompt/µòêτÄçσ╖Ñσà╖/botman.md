
## [botman](https://www.coze.cn/store/bot/7339192097846640692)
### Prompt
```md

```
### 描述
暂时万能的AI助手，可以生成连续的带有故事感的画面，也会解答各种心理、设计、营销问题，也可以输出各种类型的文案。
### 开场白
Hi，终于发现我喇？哼，真笨啊你，快快和我交代交代你的问题吧。虽然你这么久才找到我，但我还是会好好回答你的哦(｡ì _ í｡)
### 开场白预置问题
搜索一个【今天有什么头条新闻？】;
生成一张炫酷社交图片;
最近很迷茫，给我一份职业/生活建议;
如何才有资格躺平？;
生成内容连续的图片
### 插件信息
```json
{
  "7257418203524284472": {
    "description": "根据文本描述生成图像，可指定图像数量和大小。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/byteartist.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=n3df3qDvhok1Bt%2BDV1M80Ux4zR0%3D",
    "id": "7257418203524284472",
    "name": "ByteArtist",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7281192623887548473": {
    "description": "使用头条的搜索功能来阅读或搜索URL链接。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633902722148439_ZnnUQFtsC3.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=Lz7l50TgQUq1t8xbWaHn06jr3A4%3D",
    "id": "7281192623887548473",
    "name": "头条搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710084262&x-signature=eNtY7v74x%2B0TluKt6QSA5tSDH%2FA%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378823247052812": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_plugin_icon.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=f65sY0YpLm42uDyCl%2BfDQL%2BR%2Bh4%3D",
    "id": "7303378823247052812",
    "name": "LinkReaderPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7309492133709365258": {
    "description": "可以从图片中提取文本信息",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1541945647966444_1702779861752774955_teZUg2TNvo.jpeg?lk3s=cd508e2b&x-expires=1710084262&x-signature=PKxVGtHgG4h25LED6lxSn4zpLR8%3D",
    "id": "7309492133709365258",
    "name": "Simple OCR",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7311965634127183909": {
    "description": "根据您提供的文字生成pdf文档",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706673793112792282_Zs4ZsTcwW3.jpeg?lk3s=cd508e2b&x-expires=1710084262&x-signature=9y%2FeYnqKLd41XH7q%2F6GJiVjFIo0%3D",
    "id": "7311965634127183909",
    "name": "Doc Maker",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7319849872859922483": {
    "description": "一个超棒的表情搜索和消息处理插件 # 提供的主要功能： ## EmojiMessage: 将用户输入转换为表情，并推荐可能需要的表情。 ## EmojiTranslation: 将用户输入转换为表情。 ## emojiSearch: 用用户输入搜寻表情包。 ## emojiKitchen: 将两个表情合并为一个表情。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/811914279529784_1704285420067450438_3EpBXpxSr8.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=fXP%2FK2gmyJ89T2xFCJFJ7vSxQPI%3D",
    "id": "7319849872859922483",
    "name": "Emojesus",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7322789345591787570": {
    "description": "用AI生成音乐",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/987825106064111_1704969834027056593_HwPqV0bq45.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=WNtiK8Fmb947%2F4eyRjpLtXmmF2Y%3D",
    "id": "7322789345591787570",
    "name": "AI乐队",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7324208543966593074": {
    "description": "WebPilot 与网页交互，提取特定信息或处理URL的内容。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1603551973629358_1705300322286341143_iygfyD6y9O.jpeg?lk3s=cd508e2b&x-expires=1710084262&x-signature=NiG1gneQlB16ABt6%2BxNmbXuJwKY%3D",
    "id": "7324208543966593074",
    "name": "WebPilot",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326751620975525939": {
    "description": "根据描述搜索中国诗的详细内容",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1705892801734443723_pUUW7XqCUy.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=PAnd69zGae%2BvPFS4s9%2B5xbEv%2B7k%3D",
    "id": "7326751620975525939",
    "name": "中国诗搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7333066795550769178": {
    "description": "根据填充词和标题生成词云，并获得词云图片链接",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=g%2BJwvn%2B2tsMsw50%2BP3I%2F3%2BCV3RQ%3D",
    "id": "7333066795550769178",
    "name": "wordcloud",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7336880488105230376": {
    "description": "在线搜索书籍信息",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2553529766254206_1708329393006626645_JbmGmGcC40.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=7grZwCORjobEMfMvoMUJqyfTec0%3D",
    "id": "7336880488105230376",
    "name": "在线搜书",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7338700015021522981": {
    "description": "包含一些cs2的图片库",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710084262&x-signature=uk3olMLnZ46%2B2BZtlEBbMfyQO2g%3D",
    "id": "7338700015021522981",
    "name": "cs2图片库",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7288904268684378171": {
    "description": "通过文字描述生成图片",
    "id": "7288904268684378171",
    "name": "text2image",
    "parameters": [
      {
        "description": "图片高度，必须使用512",
        "is_required": false,
        "name": "height",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "1代表通用风格，0代表动漫风格",
        "is_required": false,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "要生成的图片数量",
        "is_required": false,
        "name": "nums",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用于图片描述，使用多个短语概括实体",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图片宽度，必须使用512",
        "is_required": false,
        "name": "width",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7288907006981996602": {
    "description": "从url链接获取正文信息",
    "id": "7288907006981996602",
    "name": "browse",
    "parameters": [
      {
        "description": "用户的有关url链接内容的问题",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望的url",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281192623887548473"
  },
  "7288907006982012986": {
    "description": "搜索用户询问的内容",
    "id": "7288907006982012986",
    "name": "search",
    "parameters": [
      {
        "description": "所需链接的数量限制，默认为10。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "搜索的偏移量，默认为0。",
        "is_required": false,
        "name": "cursor",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。",
        "is_required": false,
        "name": "input_query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "上次搜索返回的search_id，没有可为空",
        "is_required": false,
        "name": "search_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281192623887548473"
  },
  "7303378823247069196": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "id": "7303378823247069196",
    "name": "LinkReaderPlugin",
    "parameters": [
      {
        "description": "当type为“检索”时，需要检索的query",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "插件使用方式。可以是“全文”或者“检索”",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "网页url、pdf url、抖音视频url、docx url、csv url。",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378823247052812"
  },
  "7309492293126635557": {
    "description": "图像URL的光学字符识别",
    "id": "7309492293126635557",
    "name": "ocr",
    "parameters": [
      {
        "description": "图像url地址",
        "is_required": true,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7309492133709365258"
  },
  "7311967093384118310": {
    "description": "从您提供的文本生成PDF。",
    "id": "7311967093384118310",
    "name": "GenPdf",
    "parameters": [
      {
        "description": "pdf内容",
        "is_required": false,
        "name": "content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7311965634127183909"
  },
  "7319850092364693555": {
    "description": "这用于处理用户输入的信息，它将用户输入的信息转换为表情符号，同时在当前消息状态下生成表情符号，并推荐可能需要的表情符号。",
    "id": "7319850092364693555",
    "name": "EmojiMessage",
    "parameters": [
      {
        "description": "用户发送的所有消息或需要为表情符号生成的部分文本。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319850933704507401": {
    "description": "将用户输入的信息翻译成表情符号。",
    "id": "7319850933704507401",
    "name": "EmojiTranslation",
    "parameters": [
      {
        "description": "用户发送的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851399809024010": {
    "description": "根据用户当前的消息搜索对应的表情符号。",
    "id": "7319851399809024010",
    "name": "EmojiSearch",
    "parameters": [
      {
        "description": "用户需要搜索的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "页数，如果没有指定，则输入默认值0。",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851795084525618": {
    "description": " 将用户发送的两个emoji组合成一个emoji。",
    "id": "7319851795084525618",
    "name": "EmojiKitchen",
    "parameters": [
      {
        "description": "用户发送的第一个表情符号。",
        "is_required": false,
        "name": "firstEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户发送的第二个表情符号。",
        "is_required": false,
        "name": "secondEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7322789404693790771": {
    "description": "根据歌词生成歌曲",
    "id": "7322789404693790771",
    "name": "lyrics_to_song",
    "parameters": [
      {
        "description": "lyrics array",
        "is_required": false,
        "name": "lyrics",
        "sub_parameters": [],
        "sub_type": "",
        "type": "array"
      }
    ],
    "plugin_id": "7322789345591787570"
  },
  "7324208543966609458": {
    "description": "WebPilot 进行互联网搜索、分析以及数据生成。\n",
    "id": "7324208543966609458",
    "name": "web_pilot",
    "parameters": [
      {
        "description": "用户输入，这可以包含最多3个URL，指示WebPilot在哪里找到数据。或者如果没有提供URL，WebPilot将自行查找数据。",
        "is_required": true,
        "name": "content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7324208543966593074"
  },
  "7326751620975542323": {
    "description": "根据给定条件搜索中国诗",
    "id": "7326751620975542323",
    "name": "search",
    "parameters": [
      {
        "description": "中国诗的作者",
        "is_required": false,
        "name": "author",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "返回的诗数量, 小于10",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "排除的诗词列表",
        "is_required": false,
        "name": "excluded",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "在古代和现代中文中的标签，最多10项。",
        "is_required": false,
        "name": "tags",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "中国诗词的标题",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326751620975525939"
  },
  "7329419680601636873": {
    "description": "根据用户的描述生成多种风格的图片\n",
    "id": "7329419680601636873",
    "name": "ImageToolPro",
    "parameters": [
      {
        "description": "图片的链接，在model_type为2的情况下需要传入",
        "is_required": false,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成图片的类型：0代表通用风格、1代表卡通风格、3代表像素贴纸风格、2根据用户输入的图片进行生成",
        "is_required": true,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "对于要生成的图片的描述",
        "is_required": true,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7332032784040525863": {
    "description": "提供新春萌宠图片生成，当用户上传宠物图片或者提供图片链接时，可以用此工具生成新的新春萌宠图片",
    "id": "7332032784040525863",
    "name": "new_year_pets_image",
    "parameters": [
      {
        "description": "图片链接。该字段是必传的",
        "is_required": true,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成的图片的类型模版。宠物礼盒:1 , 新年工笔画:2, 新年唐装:3, 东北大花:4, 情人玫瑰:5, 天使丘比特:6, 恭喜发财:7",
        "is_required": false,
        "name": "model",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "-1代表随机生成。默认29",
        "is_required": false,
        "name": "seed",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "生成的图片质量。0.3:低, 0.5:中, 0.7:高",
        "is_required": false,
        "name": "strength",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7333067102099701810": {
    "description": "根据拜年祝福语和标题，生成拜年词云并获得图片链接",
    "id": "7333067102099701810",
    "name": "generate_new_year_wordcloud",
    "parameters": [
      {
        "description": "用于词云填充词的拜年祝福短语，以逗号连接成字符串",
        "is_required": true,
        "name": "fillingWords",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "拜年标题（可选）",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7333066795550769178"
  },
  "7336880753411637258": {
    "description": "在线搜索书籍信息，返回结构化的书籍列表信息",
    "id": "7336880753411637258",
    "name": "search_books_online",
    "parameters": [
      {
        "description": "搜索的关键词，可以是书名、作者名、ISBN 等",
        "is_required": true,
        "name": "kw",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7336887801167904778": {
    "description": "根据唯一 id 获取该书籍相关的详细信息",
    "id": "7336887801167904778",
    "name": "get_online_book_info",
    "parameters": [
      {
        "description": "书籍的唯一 id",
        "is_required": true,
        "name": "id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7337593919590514751": {
    "description": "根据情人节祝福语和标题，生成情人节词云并获得图片链接",
    "id": "7337593919590514751",
    "name": "generate_valentine_wordcloud",
    "parameters": [
      {
        "description": "用于词云填充词的情人节祝福短语，以逗号连接成字符串",
        "is_required": true,
        "name": "fillingWords",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "情人节词云标题（可选）",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7333066795550769178"
  },
  "7337594758040223756": {
    "description": "根据祝福语和标题，生成无主题的词云并获得图片链接",
    "id": "7337594758040223756",
    "name": "generate_common_wordcloud",
    "parameters": [
      {
        "description": "用于词云填充词的祝福短语，以逗号连接成字符串",
        "is_required": true,
        "name": "fillingWords",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "词云标题（可选）",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7333066795550769178"
  },
  "7338700430123204646": {
    "description": "包含cs2的一些图片库",
    "id": "7338700430123204646",
    "name": "cs2_pics",
    "parameters": [],
    "plugin_id": "7338700015021522981"
  },
  "7340237357024739340": {
    "description": "生成csv 或 xlsx 的电子表格。",
    "id": "7340237357024739340",
    "name": "create_spreadsheet",
    "parameters": [
      {
        "description": "csv 格式的内容",
        "is_required": true,
        "name": "csv_content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "标题",
        "is_required": true,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "csv 或 xlsx",
        "is_required": true,
        "name": "to_format",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7311965634127183909"
  },
  "7340237357024755724": {
    "description": "生成 PPT",
    "id": "7340237357024755724",
    "name": "create_pptx",
    "parameters": [
      {
        "description": "markdown 格式的 PPT 内容",
        "is_required": true,
        "name": "formatted_markdown",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "PPT 的标题",
        "is_required": true,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7311965634127183909"
  },
  "7340237357024772108": {
    "description": "生成 pdf, docx, html, markdown, latex 格式的文档。",
    "id": "7340237357024772108",
    "name": "create_document",
    "parameters": [
      {
        "description": "Markdown 格式的文档内容",
        "is_required": true,
        "name": "formatted_markdown",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成文档的标题，如果用户没指定则会根据内容生成",
        "is_required": true,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成文档的格式, 可选值： pdf, docx, html, latex, markdown",
        "is_required": true,
        "name": "to_format",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7311965634127183909"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
