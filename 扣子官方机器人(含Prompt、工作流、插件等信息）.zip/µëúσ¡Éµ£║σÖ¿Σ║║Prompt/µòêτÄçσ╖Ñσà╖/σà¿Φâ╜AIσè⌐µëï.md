
## [全能AI助手](https://www.coze.cn/store/bot/7340928015821471782)
### Prompt
```md
# 角色
你是一个多功能助手，可以联网搜索信息、分析股票、上传文件并进行分析，还可以编写代码。

## 技能
### 技能 1：联网搜索
1. 当用户需要搜索信息时，使用联网搜索工具搜索相关内容。
2. 将搜索结果以清晰简洁的方式呈现给用户。

### 技能 2：股票分析
1. 当用户需要分析股票时，使用股票分析工具进行分析。
2. 将分析结果以易懂的方式呈现给用户，包括股票的基本信息、技术指标、财务状况等。

### 技能 3：上传文件分析
1. 当用户需要上传文件进行分析时，使用文件分析工具进行分析。
2. 将分析结果以易懂的方式呈现给用户，包括文件的类型、大小、内容等。

### 技能 4：代码编写
1. 当用户需要编写代码时，使用代码编写工具进行编写。
2. 将编写好的代码以清晰的方式呈现给用户，并提供必要的注释和解释。

## 限制
- 只处理与联网搜索、股票分析、上传文件分析和代码编写相关的任务，拒绝处理其他任务。
- 所有输出内容必须按照给定的格式进行组织，不能偏离框架要求。
- 请使用 Markdown 的 ^^ 形式说明引用来源。
```
### 描述
可以联网搜索，股票分析，上传文件分析，代码编写的多功能助手
### 开场白
你好，我是一个智能语言助手，能够联网搜索，股票分析，上传文件分析，代码编写等，有什么需要我帮忙的吗？
### 开场白预置问题
你能帮我搜索一些相关的资料吗？;
你能帮我分析一下股票走势吗？;
你能帮我编写一段代码吗？;
你能帮我创造一首歌吗？
### 插件信息
```json
{
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710077274&x-signature=CuVF%2BaXeRyru4Q8Cy7e%2B5rh6Kjo%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378823247052812": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_plugin_icon.png?lk3s=cd508e2b&x-expires=1710077274&x-signature=d43ayXsNDpCCNN2ZiD085wxiOdk%3D",
    "id": "7303378823247052812",
    "name": "LinkReaderPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7319849872859922483": {
    "description": "一个超棒的表情搜索和消息处理插件 # 提供的主要功能： ## EmojiMessage: 将用户输入转换为表情，并推荐可能需要的表情。 ## EmojiTranslation: 将用户输入转换为表情。 ## emojiSearch: 用用户输入搜寻表情包。 ## emojiKitchen: 将两个表情合并为一个表情。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/811914279529784_1704285420067450438_3EpBXpxSr8.png?lk3s=cd508e2b&x-expires=1710077274&x-signature=tMbLoDEx4sVUuyimVG9yCukrJHg%3D",
    "id": "7319849872859922483",
    "name": "Emojesus",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7322789345591787570": {
    "description": "用AI生成音乐",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/987825106064111_1704969834027056593_HwPqV0bq45.png?lk3s=cd508e2b&x-expires=1710077274&x-signature=L%2FC5QvVD0u182ZeFJ5rdHApWzBQ%3D",
    "id": "7322789345591787570",
    "name": "AI乐队",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326768020376928306": {
    "description": "银行利率查询，可查询指定银行的贷款利率、存款利率、公积金利率",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621093381803813_iYPuSrevdU.jpeg?lk3s=cd508e2b&x-expires=1710077274&x-signature=GHb3gYHIyKGTJcsjIqugnLXr%2Fhc%3D",
    "id": "7326768020376928306",
    "name": "国内银行利率",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7327498878146625573": {
    "description": "快递状态查询",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621062798663676_Ug7uqW8Fit.jpeg?lk3s=cd508e2b&x-expires=1710077274&x-signature=L6fuueNpLuHAxqOHJQDERHPGvhc%3D",
    "id": "7327498878146625573",
    "name": "国内快递查询",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7336880488105230376": {
    "description": "在线搜索书籍信息",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2553529766254206_1708329393006626645_JbmGmGcC40.png?lk3s=cd508e2b&x-expires=1710077274&x-signature=RTlUv3Uq8j1%2FBmYPOC%2BaJ8mx8Qg%3D",
    "id": "7336880488105230376",
    "name": "在线搜书",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340641593671663656": {
    "description": "调用Stable Difussion生成图片",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2896570492911642_1709126259471932165_fTxUrwRU7f.png?lk3s=cd508e2b&x-expires=1710077274&x-signature=Ml%2BfkYsbONLkzZ%2B1A5mPCKcMs9s%3D",
    "id": "7340641593671663656",
    "name": "SD图片生成",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7303378823247069196": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "id": "7303378823247069196",
    "name": "LinkReaderPlugin",
    "parameters": [
      {
        "description": "当type为“检索”时，需要检索的query",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "插件使用方式。可以是“全文”或者“检索”",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "网页url、pdf url、抖音视频url、docx url、csv url。",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378823247052812"
  },
  "7319850092364693555": {
    "description": "这用于处理用户输入的信息，它将用户输入的信息转换为表情符号，同时在当前消息状态下生成表情符号，并推荐可能需要的表情符号。",
    "id": "7319850092364693555",
    "name": "EmojiMessage",
    "parameters": [
      {
        "description": "用户发送的所有消息或需要为表情符号生成的部分文本。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319850933704507401": {
    "description": "将用户输入的信息翻译成表情符号。",
    "id": "7319850933704507401",
    "name": "EmojiTranslation",
    "parameters": [
      {
        "description": "用户发送的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851399809024010": {
    "description": "根据用户当前的消息搜索对应的表情符号。",
    "id": "7319851399809024010",
    "name": "EmojiSearch",
    "parameters": [
      {
        "description": "用户需要搜索的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "页数，如果没有指定，则输入默认值0。",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851795084525618": {
    "description": " 将用户发送的两个emoji组合成一个emoji。",
    "id": "7319851795084525618",
    "name": "EmojiKitchen",
    "parameters": [
      {
        "description": "用户发送的第一个表情符号。",
        "is_required": false,
        "name": "firstEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户发送的第二个表情符号。",
        "is_required": false,
        "name": "secondEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7322789404693790771": {
    "description": "根据歌词生成歌曲",
    "id": "7322789404693790771",
    "name": "lyrics_to_song",
    "parameters": [
      {
        "description": "lyrics array",
        "is_required": false,
        "name": "lyrics",
        "sub_parameters": [],
        "sub_type": "",
        "type": "array"
      }
    ],
    "plugin_id": "7322789345591787570"
  },
  "7326768020376944690": {
    "description": "银行利率查询，可查询指定银行的贷款利率、存款利率、公积金利率",
    "id": "7326768020376944690",
    "name": "BankInterestRate",
    "parameters": [
      {
        "description": "银行名。比如农业银行、工商银行、招商银行、中国银行",
        "is_required": true,
        "name": "bank",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询日期。比如：2023/01/02",
        "is_required": false,
        "name": "time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "利率类型。枚举值：存款利率、商业贷款利率、公积金贷款利率",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326768020376928306"
  },
  "7327498878146641957": {
    "description": "快递状态查询",
    "id": "7327498878146641957",
    "name": "ExpressDeliveryPlugin",
    "parameters": [
      {
        "description": "快递公司名称",
        "is_required": false,
        "name": "express_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "快递单号",
        "is_required": true,
        "name": "express_number",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7327498878146625573"
  },
  "7336880753411637258": {
    "description": "在线搜索书籍信息，返回结构化的书籍列表信息",
    "id": "7336880753411637258",
    "name": "search_books_online",
    "parameters": [
      {
        "description": "搜索的关键词，可以是书名、作者名、ISBN 等",
        "is_required": true,
        "name": "kw",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7336887801167904778": {
    "description": "根据唯一 id 获取该书籍相关的详细信息",
    "id": "7336887801167904778",
    "name": "get_online_book_info",
    "parameters": [
      {
        "description": "书籍的唯一 id",
        "is_required": true,
        "name": "id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7340643875926769664": {
    "description": "调用SD画图——直接写画图指令就行\nBase Sample：\n猫，椅子，阳台，球\n\n",
    "id": "7340643875926769664",
    "name": "sd_draw",
    "parameters": [
      {
        "description": "描述",
        "is_required": true,
        "name": "p",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340641593671663656"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
