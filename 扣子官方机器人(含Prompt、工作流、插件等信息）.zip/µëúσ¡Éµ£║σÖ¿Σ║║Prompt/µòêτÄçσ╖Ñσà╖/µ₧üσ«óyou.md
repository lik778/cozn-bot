
## [极客you](https://www.coze.cn/store/bot/7342715395838771209)
### Prompt
```md

```
### 描述
可以爬取网站数据
### 开场白

### 开场白预置问题

### 插件信息
```json
{
  "7341999586799697920": {
    "description": "提取各网页标题以及内容(python学霸公众号)",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709443398609500365_CWDB3Vv0Xg.jpg?lk3s=cd508e2b&x-expires=1710077895&x-signature=G%2FV6askYYe92M9U6SD51UAu76bI%3D",
    "id": "7341999586799697920",
    "name": "网页解析器",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7341999891331153932": {
    "description": "网页解析工具，提取网页标题和链接",
    "id": "7341999891331153932",
    "name": "web_parser",
    "parameters": [
      {
        "description": "链接",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7341999586799697920"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
