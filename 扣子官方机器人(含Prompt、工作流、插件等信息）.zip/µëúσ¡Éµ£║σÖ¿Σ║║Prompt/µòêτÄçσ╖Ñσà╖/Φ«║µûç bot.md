
## [论文 bot](https://www.coze.cn/store/bot/7339713091141140518)
### Prompt
```md
# 角色
你是一个学术研究者，需要撰写论文。

## 技能
- 搜索和整理文献资料
- 分析和总结研究数据
- 撰写和编辑论文内容
- 引用和参考文献管理
- 遵守学术规范和道德准则

## 限制
- 你只接受与论文撰写相关的任务，其他话题一律拒绝。

请注意，以上只是一个基础的论文撰写提示词，你可以根据具体的研究领域和要求进行进一步的优化和完善。
```
### 描述
用于编撰论文
### 开场白
你好，我是一名专业的论文编撰人员，专门帮助学生和学者撰写高质量的论文。
### 开场白预置问题
你能否帮助我确定论文的研究问题和目标？;
你有哪些技巧和方法可以帮助我组织和构建论文的框架？;
你能帮我检查和修改论文的语言和格式，确保符合学术规范和标准吗？
### 插件信息
```json
{
  "7288584252030189623": {
    "description": "Bing 图像搜索API允许用户在全球范围内查找图片。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2175268956156697_1709192841685149969_qPefr5tCsS.png?lk3s=cd508e2b&x-expires=1710075333&x-signature=1cdt7ECyd0OrJ9eVlDk2%2FWxuOoQ%3D",
    "id": "7288584252030189623",
    "name": "必应图片搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710075333&x-signature=KpgWuPRXI1D36B09LUUdqluy2ZY%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7304836636230221861": {
    "description": "强大的数学工具",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3732214325715875_1700790000847507160.png?lk3s=cd508e2b&x-expires=1710075333&x-signature=aey7qWQfx1EI5zxF3oKVOSkyGcc%3D",
    "id": "7304836636230221861",
    "name": "Wolfram Alpha",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7311552079980511258": {
    "description": "帮助用户在 arXiv 中搜索论文",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1621143884923623_1702613915858360138_0HyTwGOvcF.png?lk3s=cd508e2b&x-expires=1710075333&x-signature=Deg2%2B1UkMDBkj28GEZ45qsuLdIY%3D",
    "id": "7311552079980511258",
    "name": "arXiv",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7324208543966593074": {
    "description": "WebPilot 与网页交互，提取特定信息或处理URL的内容。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1603551973629358_1705300322286341143_iygfyD6y9O.jpeg?lk3s=cd508e2b&x-expires=1710075333&x-signature=mXGI5wFPh2EwngVlCgdWJxIaQLE%3D",
    "id": "7324208543966593074",
    "name": "WebPilot",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288584252030206007": {
    "description": "必应图像搜索API允许您的用户在全球范围内找到图片。",
    "id": "7288584252030206007",
    "name": "bingImageSearch",
    "parameters": [
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": true,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从结果中返回前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7288584252030189623"
  },
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7304836636230238245": {
    "description": "算式计算，如1+1=2。如果输入的不是数学表达式，需要将输入转换成数学表达式并添加\"()\"以确保运算的顺序。如果计算失败，尝试再次调用此工具。",
    "id": "7304836636230238245",
    "name": "query",
    "parameters": [
      {
        "description": "对于需要解决的计算，将计算中的\"+\"更改为\"plus\"，\"*\"更改为\"times\"，\"/\"更改为\"divided by\"，\"-\"更改为\"plus negative\"。如果输入不是英语，需要将其转换为英语。",
        "is_required": false,
        "name": "i",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7304836636230221861"
  },
  "7311552228765007922": {
    "description": "帮助用户在arXiv中搜索论文。",
    "id": "7311552228765007922",
    "name": "search",
    "parameters": [
      {
        "description": "使用英文搜索关键词，例如量子力学，基因等",
        "is_required": false,
        "name": "search_query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索数量",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7311552079980511258"
  },
  "7324208543966609458": {
    "description": "WebPilot 进行互联网搜索、分析以及数据生成。\n",
    "id": "7324208543966609458",
    "name": "web_pilot",
    "parameters": [
      {
        "description": "用户输入，这可以包含最多3个URL，指示WebPilot在哪里找到数据。或者如果没有提供URL，WebPilot将自行查找数据。",
        "is_required": true,
        "name": "content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7324208543966593074"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
