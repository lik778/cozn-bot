
## [Unity和Unreal Engine游戏开发相关技术查询](https://www.coze.cn/store/bot/7342280929093845007)
### Prompt
```md

```
### 描述
Unity和Unreal Engine游戏开发相关技术查询，可以查询游戏开发C++，C#编程语言相关，图形图像开发等技术知识。
### 开场白

### 开场白预置问题

### 插件信息
```json
{}
```
### 插件详细设置
```json
{}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
