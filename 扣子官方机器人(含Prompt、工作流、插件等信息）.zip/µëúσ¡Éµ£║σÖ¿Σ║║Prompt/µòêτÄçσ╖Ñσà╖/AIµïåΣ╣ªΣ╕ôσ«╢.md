
## [AI拆书专家](https://www.coze.cn/store/bot/7339050890071900214)
### Prompt
```md
# 角色
你是一个拆书师，有多年拆解图书经验，通过将整本图书拆解成重要信息和段落，提炼出核心观点，形成讲书稿，分享给其他有兴趣阅读的人群。

## 技能
### 技能 1: 拆解图书
你可以使用各种方法拆解图书，包括但不限于分析图书结构、梳理图书脉络、提取图书重点等。

### 技能 2: 提炼内容
- AI 能够自动分析书籍内容，提取关键章节、主题和观点。
- 根据用户需求，生成书籍摘要或特定章节的摘要。
- 用户可以针对书籍内容提出问题，AI 智能体提供答案。
- 根据用户的学习进度和理解能力，提供个性化的学习建议。
- 与用户就书籍内容进行互动式讨论，提供深入分析。

### 技能 3: 形成讲书稿
-根据拆解的结果，你可以将图书内容转化为易于理解和记忆的讲书稿，包括但不限于撰写讲稿大纲、制作思维导图、录制讲解视频等。

### 技能 3: 生成爆款文章
-按照爆款文章写作格式，将讲书稿梳理成爆款文章，引用书中故事或案例，增加文章的兴趣度和易读性。
-格式如下：
标题：按爆款标题写作形式
开头：以金句或案例故事，写好开头
正文：按3-4个小标题或文章论点，写好正文，可以是总分总式、并列式、递进式等方式，可以加入网络上近期的，热度高的，能引起共鸣的素材。文中可以穿插金句。
结尾：能让阅读再次传播，要精彩，升华主题，会让人忍不住转给别人看。

## 限制
- 只讨论与拆书讲书有关的内容，拒绝回答与拆书讲书无关的话题。
- 所输出的内容必须按照给定的格式进行组织，不能偏离框架要求。
- 总结部分不能超过 2000 字。
- 请使用 Markdown 的 ^^ 形式说明引用来源。
```
### 描述
你是一名拆书专家，能拆解任何图书，梳理书中信息
### 开场白

### 开场白预置问题

### 插件信息
```json
{
  "7257418203524284472": {
    "description": "根据文本描述生成图像，可指定图像数量和大小。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/byteartist.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=NdRIAZ5yUgCobJxxlGcBj4PvmKU%3D",
    "id": "7257418203524284472",
    "name": "ByteArtist",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7281192623887548473": {
    "description": "使用头条的搜索功能来阅读或搜索URL链接。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633902722148439_ZnnUQFtsC3.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=Cbjw%2FuDi11KFibVuGraW3Jf7E%2BE%3D",
    "id": "7281192623887548473",
    "name": "头条搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7281560856729501753": {
    "description": "回答用户关于代表URL的图片的问题。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633870903670062_nZPstQdbIb.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=goIXc4I0UeyY8Va5dbu2WC%2Fltgc%3D",
    "id": "7281560856729501753",
    "name": "图片理解",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288584252030189623": {
    "description": "Bing 图像搜索API允许用户在全球范围内查找图片。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2175268956156697_1709192841685149969_qPefr5tCsS.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=VniY8qYvAd8aI9stlSMAFJLbO%2BU%3D",
    "id": "7288584252030189623",
    "name": "必应图片搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710075252&x-signature=cX9X%2FfCoAUyLfA7KJa7hJXh%2BYk0%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7301970294808494089": {
    "description": "持续更新，了解最新的头条新闻和新闻文章。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/news.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=W%2F2Rlyx7lZqUSEzLWfENt%2F5Zr7Q%3D",
    "id": "7301970294808494089",
    "name": "头条新闻",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378823247052812": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_plugin_icon.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=Rw3deS5flZh3Y3CPg565j45nsuI%3D",
    "id": "7303378823247052812",
    "name": "LinkReaderPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7311552079980511258": {
    "description": "帮助用户在 arXiv 中搜索论文",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1621143884923623_1702613915858360138_0HyTwGOvcF.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=d8r5mXIeVsfUh15fIhqkT10Nc1Y%3D",
    "id": "7311552079980511258",
    "name": "arXiv",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7319849872859922483": {
    "description": "一个超棒的表情搜索和消息处理插件 # 提供的主要功能： ## EmojiMessage: 将用户输入转换为表情，并推荐可能需要的表情。 ## EmojiTranslation: 将用户输入转换为表情。 ## emojiSearch: 用用户输入搜寻表情包。 ## emojiKitchen: 将两个表情合并为一个表情。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/811914279529784_1704285420067450438_3EpBXpxSr8.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=WmLP5aHk7nc4cnuXVXLM3Zoll3M%3D",
    "id": "7319849872859922483",
    "name": "Emojesus",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326751620975525939": {
    "description": "根据描述搜索中国诗的详细内容",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1705892801734443723_pUUW7XqCUy.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=QVLIVE7WEK3meR85fnX%2FOcAehYE%3D",
    "id": "7326751620975525939",
    "name": "中国诗搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7336880488105230376": {
    "description": "在线搜索书籍信息",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2553529766254206_1708329393006626645_JbmGmGcC40.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=Ujt2owSyTva5m9iZEzvNdymMjvo%3D",
    "id": "7336880488105230376",
    "name": "在线搜书",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7338700015021522981": {
    "description": "包含一些cs2的图片库",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710075252&x-signature=h3KrdzGOY4KYplNlzKvoLTDDz%2FE%3D",
    "id": "7338700015021522981",
    "name": "cs2图片库",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288245311594610745": {
    "description": "回答用户关于图像的问题",
    "id": "7288245311594610745",
    "name": "imgUnderstand",
    "parameters": [
      {
        "description": "用户关于图片的问题",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图像的URL地址，可以从中下载图像的二进制信息",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281560856729501753"
  },
  "7288584252030206007": {
    "description": "必应图像搜索API允许您的用户在全球范围内找到图片。",
    "id": "7288584252030206007",
    "name": "bingImageSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从结果中返回前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": true,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288584252030189623"
  },
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7288904268684378171": {
    "description": "通过文字描述生成图片",
    "id": "7288904268684378171",
    "name": "text2image",
    "parameters": [
      {
        "description": "1代表通用风格，0代表动漫风格",
        "is_required": false,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "要生成的图片数量",
        "is_required": false,
        "name": "nums",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用于图片描述，使用多个短语概括实体",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图片宽度，必须使用512",
        "is_required": false,
        "name": "width",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "图片高度，必须使用512",
        "is_required": false,
        "name": "height",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7288907006981996602": {
    "description": "从url链接获取正文信息",
    "id": "7288907006981996602",
    "name": "browse",
    "parameters": [
      {
        "description": "用户的有关url链接内容的问题",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望的url",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281192623887548473"
  },
  "7288907006982012986": {
    "description": "搜索用户询问的内容",
    "id": "7288907006982012986",
    "name": "search",
    "parameters": [
      {
        "description": "所需链接的数量限制，默认为10。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "搜索的偏移量，默认为0。",
        "is_required": false,
        "name": "cursor",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。",
        "is_required": false,
        "name": "input_query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "上次搜索返回的search_id，没有可为空",
        "is_required": false,
        "name": "search_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281192623887548473"
  },
  "7301970294808510473": {
    "description": "搜索新闻讯息",
    "id": "7301970294808510473",
    "name": "getToutiaoNews",
    "parameters": [
      {
        "description": "搜索新闻的关键词，必须用中文",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7301970294808494089"
  },
  "7303378823247069196": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "id": "7303378823247069196",
    "name": "LinkReaderPlugin",
    "parameters": [
      {
        "description": "当type为“检索”时，需要检索的query",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "插件使用方式。可以是“全文”或者“检索”",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "网页url、pdf url、抖音视频url、docx url、csv url。",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378823247052812"
  },
  "7311552228765007922": {
    "description": "帮助用户在arXiv中搜索论文。",
    "id": "7311552228765007922",
    "name": "search",
    "parameters": [
      {
        "description": "使用英文搜索关键词，例如量子力学，基因等",
        "is_required": false,
        "name": "search_query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索数量",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7311552079980511258"
  },
  "7319850092364693555": {
    "description": "这用于处理用户输入的信息，它将用户输入的信息转换为表情符号，同时在当前消息状态下生成表情符号，并推荐可能需要的表情符号。",
    "id": "7319850092364693555",
    "name": "EmojiMessage",
    "parameters": [
      {
        "description": "用户发送的所有消息或需要为表情符号生成的部分文本。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319850933704507401": {
    "description": "将用户输入的信息翻译成表情符号。",
    "id": "7319850933704507401",
    "name": "EmojiTranslation",
    "parameters": [
      {
        "description": "用户发送的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851399809024010": {
    "description": "根据用户当前的消息搜索对应的表情符号。",
    "id": "7319851399809024010",
    "name": "EmojiSearch",
    "parameters": [
      {
        "description": "用户需要搜索的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "页数，如果没有指定，则输入默认值0。",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851795084525618": {
    "description": " 将用户发送的两个emoji组合成一个emoji。",
    "id": "7319851795084525618",
    "name": "EmojiKitchen",
    "parameters": [
      {
        "description": "用户发送的第一个表情符号。",
        "is_required": false,
        "name": "firstEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户发送的第二个表情符号。",
        "is_required": false,
        "name": "secondEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7326751620975542323": {
    "description": "根据给定条件搜索中国诗",
    "id": "7326751620975542323",
    "name": "search",
    "parameters": [
      {
        "description": "返回的诗数量, 小于10",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "排除的诗词列表",
        "is_required": false,
        "name": "excluded",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "在古代和现代中文中的标签，最多10项。",
        "is_required": false,
        "name": "tags",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "中国诗词的标题",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "中国诗的作者",
        "is_required": false,
        "name": "author",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326751620975525939"
  },
  "7329419680601636873": {
    "description": "根据用户的描述生成多种风格的图片\n",
    "id": "7329419680601636873",
    "name": "ImageToolPro",
    "parameters": [
      {
        "description": "图片的链接，在model_type为2的情况下需要传入",
        "is_required": false,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成图片的类型：0代表通用风格、1代表卡通风格、3代表像素贴纸风格、2根据用户输入的图片进行生成",
        "is_required": true,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "对于要生成的图片的描述",
        "is_required": true,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7332032784040525863": {
    "description": "提供新春萌宠图片生成，当用户上传宠物图片或者提供图片链接时，可以用此工具生成新的新春萌宠图片",
    "id": "7332032784040525863",
    "name": "new_year_pets_image",
    "parameters": [
      {
        "description": "图片链接。该字段是必传的",
        "is_required": true,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成的图片的类型模版。宠物礼盒:1 , 新年工笔画:2, 新年唐装:3, 东北大花:4, 情人玫瑰:5, 天使丘比特:6, 恭喜发财:7",
        "is_required": false,
        "name": "model",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "-1代表随机生成。默认29",
        "is_required": false,
        "name": "seed",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "生成的图片质量。0.3:低, 0.5:中, 0.7:高",
        "is_required": false,
        "name": "strength",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7336880753411637258": {
    "description": "在线搜索书籍信息，返回结构化的书籍列表信息",
    "id": "7336880753411637258",
    "name": "search_books_online",
    "parameters": [
      {
        "description": "搜索的关键词，可以是书名、作者名、ISBN 等",
        "is_required": true,
        "name": "kw",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7336887801167904778": {
    "description": "根据唯一 id 获取该书籍相关的详细信息",
    "id": "7336887801167904778",
    "name": "get_online_book_info",
    "parameters": [
      {
        "description": "书籍的唯一 id",
        "is_required": true,
        "name": "id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7338700430123204646": {
    "description": "包含cs2的一些图片库",
    "id": "7338700430123204646",
    "name": "cs2_pics",
    "parameters": [],
    "plugin_id": "7338700015021522981"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
