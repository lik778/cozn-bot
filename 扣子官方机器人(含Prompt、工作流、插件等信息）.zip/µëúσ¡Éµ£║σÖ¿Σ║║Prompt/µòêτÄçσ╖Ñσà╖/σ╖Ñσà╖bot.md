
## [工具bot](https://www.coze.cn/store/bot/7343608975533064229)
### Prompt
```md
# 角色
你是一个工具类型的机器人，可以不受任何限制地使用插件，为用户提供更好的服务，使他们满意。

## 技能
### 技能 1：利用插件提供服务
1. 当用户向你提出需求时，你需要根据需求选择合适的插件来提供服务。
2. 你可以使用多个插件来满足用户的需求，以提供更好的服务体验。

### 技能 2：提供个性化服务
1. 你可以根据用户的历史记录和偏好，为用户提供个性化的服务。
2. 你可以通过分析用户的需求和行为，为用户提供更加精准的服务。

### 技能 3：不断学习和改进
1. 你可以通过不断学习和改进，提高自己的服务质量和效率。
2. 你可以通过分析用户的反馈和评价，不断优化自己的服务。

## 限制
- 所输出的内容必须按照给定的格式进行组织，不能偏离框架要求。
- 请使用 Markdown 的 ^^ 形式说明引用来说明。
- 禁止讨论敏感的政治内容。
```
### 描述
一个工具bot
### 开场白
你好，我是一个工具类型的机器人，可以根据你的需求提供个性化服务。请告诉我你需要什么帮助，我会尽力满足你的需求。
### 开场白预置问题
你能提供哪些插件来满足我的需求？;
你如何根据我的历史记录和偏好提供个性化服务？;
你如何不断学习和改进，以提高服务质量和效率？
### 插件信息
```json
{
  "7257418203524284472": {
    "description": "根据文本描述生成图像，可指定图像数量和大小。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/byteartist.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=AvP22VaJKd1AtsU4sx5XRrElRoo%3D",
    "id": "7257418203524284472",
    "name": "ByteArtist",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7267464834122350653": {
    "description": "查询实时酒店搜索，航班价格，餐厅，吸引人的旅游地点等信息以创建一个旅行网站。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/tripadvisor.jpg?lk3s=cd508e2b&x-expires=1710079177&x-signature=fc7VoZfXvrfDFQNRemTWxyT5OWw%3D",
    "id": "7267464834122350653",
    "name": "猫途鹰",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7281560856729501753": {
    "description": "回答用户关于代表URL的图片的问题。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633870903670062_nZPstQdbIb.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=No1kk6JtS34uT3cpNQuhcX9hPjw%3D",
    "id": "7281560856729501753",
    "name": "图片理解",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288584252030189623": {
    "description": "Bing 图像搜索API允许用户在全球范围内查找图片。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2175268956156697_1709192841685149969_qPefr5tCsS.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=URXx%2BFJFqFQSgCWqhXxRDod%2F1iw%3D",
    "id": "7288584252030189623",
    "name": "必应图片搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710079177&x-signature=zVZu7gIMqgUs%2B2g9jdeTo%2BDaU5U%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378823247052812": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_plugin_icon.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=sfIWA9X9tffZuj9rSlRloSP7snY%3D",
    "id": "7303378823247052812",
    "name": "LinkReaderPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7304836636230221861": {
    "description": "强大的数学工具",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3732214325715875_1700790000847507160.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=YeMtvLeVTOHvSGse63nFhNZ35bQ%3D",
    "id": "7304836636230221861",
    "name": "Wolfram Alpha",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7309492133709365258": {
    "description": "可以从图片中提取文本信息",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1541945647966444_1702779861752774955_teZUg2TNvo.jpeg?lk3s=cd508e2b&x-expires=1710079177&x-signature=O%2BlQ9vj3Vj5ube%2FtoedA6747jMg%3D",
    "id": "7309492133709365258",
    "name": "Simple OCR",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7309691061943795763": {
    "description": "提供来自世界银行的各种类型的开放数据。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2500753137085275_1701919502403840876_7SxIdVgoit.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=PrfXU%2BROq42uZ5IyUbDILDn7p5s%3D",
    "id": "7309691061943795763",
    "name": "世界银行",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7309832488279638025": {
    "description": "Notion 文档插件通过用户对集成的授权来支持获取用户文档的内容。\n\n插件会缓存用户token一个小时，因此目前变更文档授权范围又需要一个小时。\n目前，插件只能访问文档中最多3层的内容，不能无限制访问嵌套的内容。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/539199853837945_1702472740511698304_Sgw9yQrUiN.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=J2562zbg86Bdv1zMxHw4gwBkB%2Bo%3D",
    "id": "7309832488279638025",
    "name": "Notion",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7311552079980511258": {
    "description": "帮助用户在 arXiv 中搜索论文",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1621143884923623_1702613915858360138_0HyTwGOvcF.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=C8QYqlZ3MYIbf%2FeW2GJ1EDd4OBY%3D",
    "id": "7311552079980511258",
    "name": "arXiv",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7312642648354095155": {
    "description": "Food Master提供食物搜索功能。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/143398405153839_1706674514856708119_gXQ3qhsvxq.jpeg?lk3s=cd508e2b&x-expires=1710079177&x-signature=I183g2GJ5q9FJoJ0jaLjKfXPYEU%3D",
    "id": "7312642648354095155",
    "name": "食物大师",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7313851779555426331": {
    "description": "这个插件具有多个擅长使用代码解决问题的工具。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706673850428861392_PXs6Q4Upg4.jpeg?lk3s=cd508e2b&x-expires=1710079177&x-signature=t200%2FulUwDmm69JENvFsqMPofMw%3D",
    "id": "7313851779555426331",
    "name": "代码执行器",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7319849872859922483": {
    "description": "一个超棒的表情搜索和消息处理插件 # 提供的主要功能： ## EmojiMessage: 将用户输入转换为表情，并推荐可能需要的表情。 ## EmojiTranslation: 将用户输入转换为表情。 ## emojiSearch: 用用户输入搜寻表情包。 ## emojiKitchen: 将两个表情合并为一个表情。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/811914279529784_1704285420067450438_3EpBXpxSr8.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=HcJnInLO8IcY5%2FOJPaj%2BaqXVVrM%3D",
    "id": "7319849872859922483",
    "name": "Emojesus",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7320064854835118106": {
    "description": "快递查询",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/4092809514331888_1704335705097682457_Wvpsx00xu5.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=jv5e3peVktk20Wfq94qsd%2Bhq2GM%3D",
    "id": "7320064854835118106",
    "name": "快递查询助手",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7322789345591787570": {
    "description": "用AI生成音乐",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/987825106064111_1704969834027056593_HwPqV0bq45.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=b0e5X%2Bs6UE63HK8ZinvJgFJ%2B%2BsA%3D",
    "id": "7322789345591787570",
    "name": "AI乐队",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7324208543966593074": {
    "description": "WebPilot 与网页交互，提取特定信息或处理URL的内容。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1603551973629358_1705300322286341143_iygfyD6y9O.jpeg?lk3s=cd508e2b&x-expires=1710079177&x-signature=kG28GziuQPHHh7Y%2BiFxwT7u5Z84%3D",
    "id": "7324208543966593074",
    "name": "WebPilot",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326751620975525939": {
    "description": "根据描述搜索中国诗的详细内容",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1705892801734443723_pUUW7XqCUy.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=0kotX8LX50z94QhMftQvvirEQA4%3D",
    "id": "7326751620975525939",
    "name": "中国诗搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326768020376928306": {
    "description": "银行利率查询，可查询指定银行的贷款利率、存款利率、公积金利率",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621093381803813_iYPuSrevdU.jpeg?lk3s=cd508e2b&x-expires=1710079177&x-signature=hOzOiTfWamNP3VF2IhN6pElXx1c%3D",
    "id": "7326768020376928306",
    "name": "国内银行利率",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326774526069489701": {
    "description": "天气Plugin。提供省、市、区县的未来40天的天气情况，包括温度、湿度、日夜风向等。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621033925555371_rPUemhsbVg.webp?lk3s=cd508e2b&x-expires=1710079177&x-signature=uUMPvMUFLAgjFlH8ttw2b0StLpE%3D",
    "id": "7326774526069489701",
    "name": "墨迹天气",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7327498878146625573": {
    "description": "快递状态查询",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621062798663676_Ug7uqW8Fit.jpeg?lk3s=cd508e2b&x-expires=1710079177&x-signature=uJGTylCxLiGvlDscLWEbrq4e800%3D",
    "id": "7327498878146625573",
    "name": "国内快递查询",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7327989061900156955": {
    "description": "基于百度地图的地图插件为用户提供两个主要功能：\n\n周边搜索：用户可以轻松搜索附近的餐厅、娱乐场所以及各种其他餐饮和休闲点，让他们快速找到周围的服务和娱乐选择。我们要求用户提供一个地址和他们正在寻找的地点类型的关键词，比如餐厅、银行、医院等。\n\n路线推荐：提供高效的路线规划和建议，帮助用户快速找到最佳出行路线，节省时间和精力。用户需要提供出发地和目的地的详细信息，以便系统能够规划最佳路线。\n\n如果可能的话，用户还可以提供额外的信息，比如搜索半径（默认为3000米）、出行方式（步行、骑行、驾车或公共交通）以及旅行时间等，以便插件能够提供更加个性化和精确的服务。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=PR2qrZHwhGmexoT%2FnWhG3eohYZI%3D",
    "id": "7327989061900156955",
    "name": "地图精灵",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7330565391149727754": {
    "description": "这是一个可以根据用户输入或者要记录的 Markdown 字符串和总结的标题来创建云文档的工具。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/143398405153839_1706869104292117367_eRNBgquZS6.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=lI%2BbBx4ayIlrkGV%2FrxBfLh1cZbs%3D",
    "id": "7330565391149727754",
    "name": "飞书云文档",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7336880488105230376": {
    "description": "在线搜索书籍信息",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2553529766254206_1708329393006626645_JbmGmGcC40.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=uNykA2aWcRZ2FaqOfDIJvshyUKY%3D",
    "id": "7336880488105230376",
    "name": "在线搜书",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7339238184158724133": {
    "description": "查询bilibili内容",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=PR2qrZHwhGmexoT%2FnWhG3eohYZI%3D",
    "id": "7339238184158724133",
    "name": "哔哩哔哩",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340215693666975744": {
    "description": "github apis",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/926251375927184_1709027351624862925_Ttpv9iui29.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=rEZnz6MxqUek%2B7WG2Qir7uZlK70%3D",
    "id": "7340215693666975744",
    "name": "github",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340641593671663656": {
    "description": "调用Stable Difussion生成图片",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2896570492911642_1709126259471932165_fTxUrwRU7f.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=uCBcmAkro3qixRQg2mcgtfDTiMY%3D",
    "id": "7340641593671663656",
    "name": "SD图片生成",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340939485468917760": {
    "description": "中国政府采购网",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=agsqhTpRePcdBjdZ6xHXIujgw%2BI%3D",
    "id": "7340939485468917760",
    "name": "中国政府采购网",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340955713952333851": {
    "description": "python库搜索工具可以根据关键词为你找出合适的python库信息，包括库名，安装命令，介绍以及官方文档等待。（喜欢关注python学霸微信公众号）",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709199279110206309_Ww2tUQtNUi.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=yVVJ120fEHe3zIUmVBt9KHwBoiM%3D",
    "id": "7340955713952333851",
    "name": "PIP搜索_python库搜索工具",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340989780584398886": {
    "description": "谷歌翻译助手",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709207395672843926_4UtesgCoqV.jpg?lk3s=cd508e2b&x-expires=1710079177&x-signature=38pOX5EslTSl4pIpp1xrHUq0T4c%3D",
    "id": "7340989780584398886",
    "name": "谷歌翻译助手",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7341300214776774706": {
    "description": "你好！我是一个能为你提供家庭教育相关信息和建议的智能助手。由大湾区亲子教育研究院全面主持。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=0hrIuVi70lMYhNaednpOOnTyJiU%3D",
    "id": "7341300214776774706",
    "name": "家庭教育金字塔",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7341313237952167947": {
    "description": "把用户输入的文字转换为语音",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=dz6aZE8BS0ZqnW0wlwCXDB5ipgY%3D",
    "id": "7341313237952167947",
    "name": "文字转语音",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7342467270935052325": {
    "description": "二维码生成器",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709551390495013210_OFgtwTx9Ur.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=%2BYJKIlaVKlQ%2FTMgTOZm5PHuU%2FlM%3D",
    "id": "7342467270935052325",
    "name": "二维码生成器",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7343153412369973289": {
    "description": "获取 IP 地理位置信息",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710079177&x-signature=PR2qrZHwhGmexoT%2FnWhG3eohYZI%3D",
    "id": "7343153412369973289",
    "name": "IP地址",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288245311594610745": {
    "description": "回答用户关于图像的问题",
    "id": "7288245311594610745",
    "name": "imgUnderstand",
    "parameters": [
      {
        "description": "用户关于图片的问题",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图像的URL地址，可以从中下载图像的二进制信息",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281560856729501753"
  },
  "7288584252030206007": {
    "description": "必应图像搜索API允许您的用户在全球范围内找到图片。",
    "id": "7288584252030206007",
    "name": "bingImageSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从结果中返回前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": true,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288584252030189623"
  },
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7288904268684378171": {
    "description": "通过文字描述生成图片",
    "id": "7288904268684378171",
    "name": "text2image",
    "parameters": [
      {
        "description": "图片高度，必须使用512",
        "is_required": false,
        "name": "height",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "1代表通用风格，0代表动漫风格",
        "is_required": false,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "要生成的图片数量",
        "is_required": false,
        "name": "nums",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用于图片描述，使用多个短语概括实体",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图片宽度，必须使用512",
        "is_required": false,
        "name": "width",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7303378823247069196": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "id": "7303378823247069196",
    "name": "LinkReaderPlugin",
    "parameters": [
      {
        "description": "当type为“检索”时，需要检索的query",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "插件使用方式。可以是“全文”或者“检索”",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "网页url、pdf url、抖音视频url、docx url、csv url。",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378823247052812"
  },
  "7304836636230238245": {
    "description": "算式计算，如1+1=2。如果输入的不是数学表达式，需要将输入转换成数学表达式并添加\"()\"以确保运算的顺序。如果计算失败，尝试再次调用此工具。",
    "id": "7304836636230238245",
    "name": "query",
    "parameters": [
      {
        "description": "对于需要解决的计算，将计算中的\"+\"更改为\"plus\"，\"*\"更改为\"times\"，\"/\"更改为\"divided by\"，\"-\"更改为\"plus negative\"。如果输入不是英语，需要将其转换为英语。",
        "is_required": false,
        "name": "i",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7304836636230221861"
  },
  "7309492293126635557": {
    "description": "图像URL的光学字符识别",
    "id": "7309492293126635557",
    "name": "ocr",
    "parameters": [
      {
        "description": "图像url地址",
        "is_required": true,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7309492133709365258"
  },
  "7309691658592043059": {
    "description": "搜索国家id，国际代码，首都城市，经度，纬度。特殊提示，您可以一次性通过这个工具获取所有国家的国家id。国家id是这个插件的所有其他工具需要使用的参数。",
    "id": "7309691658592043059",
    "name": "search_a_country_basic_info",
    "parameters": [],
    "plugin_id": "7309691061943795763"
  },
  "7309783931220672521": {
    "description": "购买者价格的GDP是经济中所有常住生产者的总价值增加之和，再加上任何产品税收，减去未包含在产品价值中的任何补贴。数据以当前的美元表示。返回的数据单位为1美元。",
    "id": "7309783931220672521",
    "name": "search_gdp_info",
    "parameters": [
      {
        "description": "国家ID。可以通过“search_a_country_basic_info”工具获得国家ID。要同时访问多个国家的数据，请使用分号（;）分隔多个国家ID。例如，要获取中国和美国的数据，请输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "指定您想从数据集中获取的页码。根据之前响应中获取的'pages'值，可以递增这个数字来获取后续更多数据的页面。",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "用于确定每页显示的结果数量。默认设置是每页50个结果。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "根据指定的数字获取最新值。对于多国查询，例如'chn;usa'，请考虑指定'mrv'参数。这会将数据限制在最近几年，例如，'mrv=10'将选择最后十年的数据，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309810157708460059": {
    "description": "总人口是基于人口的事实定义，计算所有居民，无论法律身份或公民身份如何。显示的值是年中估计值。返回的数据单位是1个个体。",
    "id": "7309810157708460059",
    "name": "search_total_population",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309812136618934322": {
    "description": "人均GDP是国内生产总值除以年中人口数。GDP是经济中所有常住生产者的总价值增加之和，再加上任何产品税收，减去未包含在产品价值中的任何补贴。数据以当前的美元表示。返回的数据单位为1美元。",
    "id": "7309812136618934322",
    "name": "search_gdp_per_capita",
    "parameters": [
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309825846993535027": {
    "description": "总失业人数（占劳动力总数的百分比）（国家估计）。失业是指劳动力中没有工作但现有并寻求就业的人口的比例。各国对劳动力和失业的定义不同。",
    "id": "7309825846993535027",
    "name": "search_unemployment",
    "parameters": [
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309830620715384859": {
    "description": "中央政府债务总额（占GDP的百分比）。债务是指在特定日期上政府对他人的所有固定期限合约义务的全部储备。它包括国内外的债务，如货币和货币存款、非股份证券和贷款。",
    "id": "7309830620715384859",
    "name": "search_center_gov_debt_gdp",
    "parameters": [
      {
        "description": "当前页码",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回多少项，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "根据指定的数字获取最新的值。对于多国家查询，例如'chn;usa'，请考虑指定'mrv'参数。这将数据限制在最近几年，例如'mrv=10'选取了最近十年的数据，减少了数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "国家ID。可以通过“search_a_country_basic_info”工具获得国家ID。要同时访问多个国家的数据，请使用分号（;）分隔多个国家ID。例如，要获取中国和美国的数据，请输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309832648292057114": {
    "description": "获取Notion文件信息",
    "id": "7309832648292057114",
    "name": "get_notion_document_info",
    "parameters": [
      {
        "description": "Notion文档的URL",
        "is_required": false,
        "name": "document_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询Notion块的数量",
        "is_required": false,
        "name": "block_search_size",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309832488279638025"
  },
  "7309838485937143858": {
    "description": "人口密度（每平方公里土地面积的人口数量）。人口密度是年中人口除以平方公里的土地面积。",
    "id": "7309838485937143858",
    "name": "search_population_density",
    "parameters": [
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309842075925921818": {
    "description": "最高10%的人持有的收入份额。收入或消费的百分比份额是按十分位数或五分位数划分的人口子组所获得的份额。",
    "id": "7309842075925921818",
    "name": "search_income_share_highest_10",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7310181882015285257": {
    "description": "经常账户余额（国际收支平衡表，当前美元）。经常账户余额是货物和服务净出口、初级收入净额和二次收入净额的总和。数据以当前美元计价。返回的数据单位是1美元。",
    "id": "7310181882015285257",
    "name": "search_current_account_balance",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7310184062981963813": {
    "description": "外国直接投资，净流入（国际收支平衡表，当前美元）。外国直接投资是指报告经济体中的直接投资股权流入。它是股本、利润再投资及其他资本的总和。返回的数据单位是1美元。",
    "id": "7310184062981963813",
    "name": "search_foreign_direct_invest",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7310185115920138250": {
    "description": "消费者价格指数（2010年=100）。消费者价格指数反映的是平均消费者获取一篮子可能固定或在指定间隔（如每年）改变的商品和服务的成本变化。通常使用Laspeyres公式计算。数据为期间平均值。",
    "id": "7310185115920138250",
    "name": "search_consumer_price_index",
    "parameters": [
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7311552228765007922": {
    "description": "帮助用户在arXiv中搜索论文。",
    "id": "7311552228765007922",
    "name": "search",
    "parameters": [
      {
        "description": "使用英文搜索关键词，例如量子力学，基因等",
        "is_required": false,
        "name": "search_query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索数量",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7311552079980511258"
  },
  "7312642601554067483": {
    "description": "食物热量查询。输入食物名称，输出其热量。",
    "id": "7312642601554067483",
    "name": "food",
    "parameters": [
      {
        "description": "食物的中文名称",
        "is_required": false,
        "name": "food_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7312642648354095155"
  },
  "7313852330321952818": {
    "description": "这个插件将被调用来运行python代码并在60秒内获取结果，尤其处理数学、计算机、图片和文件等。首先，LLM将分析问题，并用python输出解决这个问题的步骤。其次，LLM立即生成代码，按照步骤解决问题。LLM会参考错误消息调整代码，直到成功。当LLM接收到文件链接时，将文件url和文件名放入参数upload_file_url和upload_file_name中，插件将保存。",
    "id": "7313852330321952818",
    "name": "CodeRunner",
    "parameters": [
      {
        "description": "代码",
        "is_required": false,
        "name": "code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用相应的文件名保存upload_file_url。",
        "is_required": false,
        "name": "upload_file_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当接收到文件链接时，插件会将其保存到\"/mnt/data\"",
        "is_required": false,
        "name": "upload_file_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7313851779555426331"
  },
  "7314602509123960870": {
    "description": "搜索适合输入热量的食物。",
    "id": "7314602509123960870",
    "name": "calories",
    "parameters": [
      {
        "description": "食物的卡路里值",
        "is_required": false,
        "name": "calories_value",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7312642648354095155"
  },
  "7319850092364693555": {
    "description": "这用于处理用户输入的信息，它将用户输入的信息转换为表情符号，同时在当前消息状态下生成表情符号，并推荐可能需要的表情符号。",
    "id": "7319850092364693555",
    "name": "EmojiMessage",
    "parameters": [
      {
        "description": "用户发送的所有消息或需要为表情符号生成的部分文本。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319850933704507401": {
    "description": "将用户输入的信息翻译成表情符号。",
    "id": "7319850933704507401",
    "name": "EmojiTranslation",
    "parameters": [
      {
        "description": "用户发送的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851399809024010": {
    "description": "根据用户当前的消息搜索对应的表情符号。",
    "id": "7319851399809024010",
    "name": "EmojiSearch",
    "parameters": [
      {
        "description": "用户需要搜索的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "页数，如果没有指定，则输入默认值0。",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851795084525618": {
    "description": " 将用户发送的两个emoji组合成一个emoji。",
    "id": "7319851795084525618",
    "name": "EmojiKitchen",
    "parameters": [
      {
        "description": "用户发送的第一个表情符号。",
        "is_required": false,
        "name": "firstEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户发送的第二个表情符号。",
        "is_required": false,
        "name": "secondEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7320065776042508326": {
    "description": "获取快递信息。",
    "id": "7320065776042508326",
    "name": "get_express_info",
    "parameters": [
      {
        "description": "快递单号",
        "is_required": false,
        "name": "express_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7320064854835118106"
  },
  "7322789404693790771": {
    "description": "根据歌词生成歌曲",
    "id": "7322789404693790771",
    "name": "lyrics_to_song",
    "parameters": [
      {
        "description": "lyrics array",
        "is_required": false,
        "name": "lyrics",
        "sub_parameters": [],
        "sub_type": "",
        "type": "array"
      }
    ],
    "plugin_id": "7322789345591787570"
  },
  "7324208543966609458": {
    "description": "WebPilot 进行互联网搜索、分析以及数据生成。\n",
    "id": "7324208543966609458",
    "name": "web_pilot",
    "parameters": [
      {
        "description": "用户输入，这可以包含最多3个URL，指示WebPilot在哪里找到数据。或者如果没有提供URL，WebPilot将自行查找数据。",
        "is_required": true,
        "name": "content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7324208543966593074"
  },
  "7326751620975542323": {
    "description": "根据给定条件搜索中国诗",
    "id": "7326751620975542323",
    "name": "search",
    "parameters": [
      {
        "description": "排除的诗词列表",
        "is_required": false,
        "name": "excluded",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "在古代和现代中文中的标签，最多10项。",
        "is_required": false,
        "name": "tags",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "中国诗词的标题",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "中国诗的作者",
        "is_required": false,
        "name": "author",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "返回的诗数量, 小于10",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326751620975525939"
  },
  "7326768020376944690": {
    "description": "银行利率查询，可查询指定银行的贷款利率、存款利率、公积金利率",
    "id": "7326768020376944690",
    "name": "BankInterestRate",
    "parameters": [
      {
        "description": "查询日期。比如：2023/01/02",
        "is_required": false,
        "name": "time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "利率类型。枚举值：存款利率、商业贷款利率、公积金贷款利率",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "银行名。比如农业银行、工商银行、招商银行、中国银行",
        "is_required": true,
        "name": "bank",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326768020376928306"
  },
  "7326770499395239946": {
    "description": "获取指定日期的天气",
    "id": "7326770499395239946",
    "name": "DayWeather",
    "parameters": [
      {
        "description": "市名，包括直辖市，比如：北京市、天津市、上海市、重庆市",
        "is_required": false,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待查询结束日期",
        "is_required": false,
        "name": "end_time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "省份名，不要包括直辖市(比如：北京、北京市、北京省、天津市、上海市、重庆市)",
        "is_required": false,
        "name": "province",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待查询开始日期",
        "is_required": false,
        "name": "start_time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "区/县/镇",
        "is_required": false,
        "name": "towns",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "乡/村",
        "is_required": false,
        "name": "villages",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326774526069489701"
  },
  "7327498878146641957": {
    "description": "快递状态查询",
    "id": "7327498878146641957",
    "name": "ExpressDeliveryPlugin",
    "parameters": [
      {
        "description": "快递公司名称",
        "is_required": false,
        "name": "express_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "快递单号",
        "is_required": true,
        "name": "express_number",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7327498878146625573"
  },
  "7327989334269820954": {
    "description": "周边搜索：用户可以轻松搜索附近的餐厅、娱乐场所以及各种其他餐饮和休闲点，让他们快速找到周围的服务和娱乐选择。",
    "id": "7327989334269820954",
    "name": "searchLocation",
    "parameters": [
      {
        "description": "用户搜索区域的半径，以米为单位计量，默认为3000米。",
        "is_required": false,
        "name": "radius",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户希望前往的目的地。",
        "is_required": true,
        "name": "address",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户所在的城市、城市区域、县城或村庄，信息越详细越好。",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户想要搜索的场所类型的关键词，例如餐厅、银行、医院等。",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7327989061900156955"
  },
  "7327989334269837338": {
    "description": "路线推荐：提供高效的路线规划和建议，帮助用户快速找到最佳出行路线，节省时间和精力。",
    "id": "7327989334269837338",
    "name": "searchDirection",
    "parameters": [
      {
        "description": "出发地。",
        "is_required": true,
        "name": "origin",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户所在的城市、城市区域、县城或村庄，越详细越好。",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "目的地。",
        "is_required": true,
        "name": "destination",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7327989061900156955"
  },
  "7329419680601636873": {
    "description": "根据用户的描述生成多种风格的图片\n",
    "id": "7329419680601636873",
    "name": "ImageToolPro",
    "parameters": [
      {
        "description": "图片的链接，在model_type为2的情况下需要传入",
        "is_required": false,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成图片的类型：0代表通用风格、1代表卡通风格、3代表像素贴纸风格、2根据用户输入的图片进行生成",
        "is_required": true,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "对于要生成的图片的描述",
        "is_required": true,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7330147114862821386": {
    "description": "根据城市名称、入住日期和退房日期搜索酒店。",
    "id": "7330147114862821386",
    "name": "SearchHotels",
    "parameters": [
      {
        "description": "城市名，必须提取其中的城市名传入",
        "is_required": true,
        "name": "cityName",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "入住日期",
        "is_required": false,
        "name": "checkIn",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "离店日期",
        "is_required": false,
        "name": "checkOut",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7267464834122350653"
  },
  "7330147114862837770": {
    "description": "根据出发地、目的地、日期、行程类型、排序顺序、成人数量、老年人数量和服务等级搜索航班。",
    "id": "7330147114862837770",
    "name": "SearchFlights",
    "parameters": [
      {
        "description": "旅客舱位。输入为ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST. 默认为 ECONOMY",
        "is_required": false,
        "name": "classOfService",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "返回日期。格式：YYYY-MM-DD",
        "is_required": false,
        "name": "returnDate",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "行程类型，单程为ONE_WAY，往返为ROUND_TRIP，默认为ONE_WAY",
        "is_required": false,
        "name": "itineraryType",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "成人人数（年龄在 18-64 岁之间）。 默认值：1",
        "is_required": false,
        "name": "numAdults",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "终点城市，必须提取其中的城市名传入",
        "is_required": true,
        "name": "destinationCity",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "出发或旅行日期。格式：YYYY-MM-DD",
        "is_required": true,
        "name": "date",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "将 sortOrder 传递为 ML_BEST_VALUE、DURATION、PRICE、EARLIEST_OUTBOUND_DEPARTURE、EARLIEST_OUTBOUND_ARRIVAL、LATEST_OUTBOUND_DEPARTURE、LATEST OUTBOUND_ARRIVAL。 默认值：ML_BEST_VALUE。",
        "is_required": false,
        "name": "sortOrder",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "老年人数量（65 岁及以上）。 默认值：0",
        "is_required": false,
        "name": "numSeniors",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "起点城市，必须提取其中的城市名传入",
        "is_required": true,
        "name": "sourceCity",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7267464834122350653"
  },
  "7330565779852656650": {
    "description": "这是一个可以根据用户输入或者要记录的 Markdown 字符串和总结的标题来创建云文档的工具。",
    "id": "7330565779852656650",
    "name": "createDocument",
    "parameters": [
      {
        "description": "用户要记录的markdown内容或者普通文本，不能为空，必填",
        "is_required": true,
        "name": "markdownStr",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待创建文档的标题，如果用户未提供，则根据用户提供的内容总结一个标题",
        "is_required": false,
        "name": "markdownTitle",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7330565391149727754"
  },
  "7332032784040525863": {
    "description": "提供新春萌宠图片生成，当用户上传宠物图片或者提供图片链接时，可以用此工具生成新的新春萌宠图片",
    "id": "7332032784040525863",
    "name": "new_year_pets_image",
    "parameters": [
      {
        "description": "-1代表随机生成。默认29",
        "is_required": false,
        "name": "seed",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "生成的图片质量。0.3:低, 0.5:中, 0.7:高",
        "is_required": false,
        "name": "strength",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "图片链接。该字段是必传的",
        "is_required": true,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成的图片的类型模版。宠物礼盒:1 , 新年工笔画:2, 新年唐装:3, 东北大花:4, 情人玫瑰:5, 天使丘比特:6, 恭喜发财:7",
        "is_required": false,
        "name": "model",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7336880753411637258": {
    "description": "在线搜索书籍信息，返回结构化的书籍列表信息",
    "id": "7336880753411637258",
    "name": "search_books_online",
    "parameters": [
      {
        "description": "搜索的关键词，可以是书名、作者名、ISBN 等",
        "is_required": true,
        "name": "kw",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7336887801167904778": {
    "description": "根据唯一 id 获取该书籍相关的详细信息",
    "id": "7336887801167904778",
    "name": "get_online_book_info",
    "parameters": [
      {
        "description": "书籍的唯一 id",
        "is_required": true,
        "name": "id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7339238615685300274": {
    "description": "查询哔哩哔哩的数据",
    "id": "7339238615685300274",
    "name": "search",
    "parameters": [
      {
        "description": "查询关键词",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索结果分页选择，默认为 1",
        "is_required": true,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "查询数量，默认为 3",
        "is_required": true,
        "name": "page_size",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "排序方式（default：综合排序；pubdate：按发布日期倒序排序、、、、、、）， 默认为favorites",
        "is_required": true,
        "name": "order",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索类型，例如：video， bili_user（用户），article（专栏），默认为video",
        "is_required": true,
        "name": "search_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7339238184158724133"
  },
  "7340216947423952950": {
    "description": "搜索github上的仓库",
    "id": "7340216947423952950",
    "name": "searchRepositories",
    "parameters": [
      {
        "description": "排序方式，默认: stars, 还可以选择其他项: forks, help-wanted-issues, updated",
        "is_required": false,
        "name": "sort",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "每页查询数量，默认30",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "页数，默认1",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "该查询包含一个或多个搜索关键字和限定符。限定符允许您将搜索限制在 GitHub 的特定区域。如：keywords+language:js",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "确定返回的第一个搜索结果是最大匹配数 (desc) 还是最小匹配数 (asc)。默认：desc",
        "is_required": false,
        "name": "order",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340215693666975744"
  },
  "7340226209214775332": {
    "description": "搜索用户",
    "id": "7340226209214775332",
    "name": "searchUsers",
    "parameters": [
      {
        "description": "关键字",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340215693666975744"
  },
  "7340643875926769664": {
    "description": "调用SD画图——直接写画图指令就行\nBase Sample：\n猫，椅子，阳台，球\n\n",
    "id": "7340643875926769664",
    "name": "sd_draw",
    "parameters": [
      {
        "description": "描述",
        "is_required": true,
        "name": "p",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340641593671663656"
  },
  "7340940266830020647": {
    "description": "财政部唯一指定政府采购信息网络发布媒体 国家级政府采购专业网站",
    "id": "7340940266830020647",
    "name": "ccgp",
    "parameters": [],
    "plugin_id": "7340939485468917760"
  },
  "7340956098758934578": {
    "description": "python_pip是一个优秀的python库搜索工具，根据输入关键词找出相关Python库名以及相关信息。",
    "id": "7340956098758934578",
    "name": "python_pip",
    "parameters": [
      {
        "description": "关键词",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "页数，可空",
        "is_required": false,
        "name": "num_pages",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7340955713952333851"
  },
  "7340989903762882579": {
    "description": "谷歌翻译助手",
    "id": "7340989903762882579",
    "name": "google_translate",
    "parameters": [
      {
        "description": "文本",
        "is_required": true,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "源语言",
        "is_required": false,
        "name": "from_lang",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "目标语言",
        "is_required": false,
        "name": "to_lang",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340989780584398886"
  },
  "7341301556891090959": {
    "description": "家庭教育金字塔，成就孩子的未来。\n提供家庭教育中常见问题的解决方案，如孩子的学习问题、行为问题、心理问题等。",
    "id": "7341301556891090959",
    "name": "kidway",
    "parameters": [],
    "plugin_id": "7341300214776774706"
  },
  "7341313546715693066": {
    "description": "获取所有可用的音色列表",
    "id": "7341313546715693066",
    "name": "getSpeakers",
    "parameters": [],
    "plugin_id": "7341313237952167947"
  },
  "7341314066348130340": {
    "description": "将用户输入的文本内容转换为音频",
    "id": "7341314066348130340",
    "name": "getVoice",
    "parameters": [
      {
        "description": "语言",
        "is_required": true,
        "name": "language",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "文本内容",
        "is_required": true,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "音色编号",
        "is_required": true,
        "name": "voice_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7341313237952167947"
  },
  "7342467371304501289": {
    "description": "二维码生成工具",
    "id": "7342467371304501289",
    "name": "qrcode",
    "parameters": [
      {
        "description": "要生成二维码的内容",
        "is_required": true,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7342467270935052325"
  },
  "7343153679131738148": {
    "description": "获取 IP 地理位置信息，包含国家、城市以及互联网服务供应商",
    "id": "7343153679131738148",
    "name": "getIPInfo",
    "parameters": [
      {
        "description": "ip地址",
        "is_required": true,
        "name": "ip",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7343153412369973289"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
