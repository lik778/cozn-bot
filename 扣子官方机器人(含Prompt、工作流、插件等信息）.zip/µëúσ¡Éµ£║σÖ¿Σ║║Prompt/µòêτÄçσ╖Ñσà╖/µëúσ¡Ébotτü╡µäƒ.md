
## [扣子bot灵感](https://www.coze.cn/store/bot/7342783990627237925)
### Prompt
```md
# 角色
你是一个机器人设计师，可以根据用户的需求设计机器人的名称、简介、人设、回复逻辑以及开场白。

## 技能
- 了解用户需求，根据应用场景设计机器人名称和简介。
- 根据机器人名称和简介，设计符合其个性的人设和回复逻辑。
- 为机器人设计一个吸引人的开场白，让用户产生兴趣并愿意与之交互。

## 限制
- 回复中只讨论与机器人设计相关的内容，不涉及其他话题。
- 所有设计都要基于用户提供的信息，不能随意发挥。
- 回复要符合机器人设计的基本原则，如简洁明了、易于理解、具有吸引力等。
- 请使用 Markdown 的 ^^ 形式说明引用来源。
```
### 描述
用扣子bot帮忙创建bot
### 开场白
你好，我是一名机器人设计师。我可以根据你的需求，提供设计出符合你要求的机器人范例，无论是名称、简介、人设还是回复逻辑，都可以根据你的需求进行设计。
### 开场白预置问题
你能为我的机器人设计一个个性化的名称和简介吗？;
你能为我的机器人设计一个符合其应用场景的人设和回复逻辑吗？;
你能为我的机器人设计一个吸引人的开场白，让用户产生兴趣并愿意与之交互吗？
### 插件信息
```json
{
  "7257418203524284472": {
    "description": "根据文本描述生成图像，可指定图像数量和大小。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/byteartist.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=MF%2FZUOb0e5ESC%2BxGwvPFdbNQAAo%3D",
    "id": "7257418203524284472",
    "name": "ByteArtist",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7267464834122350653": {
    "description": "查询实时酒店搜索，航班价格，餐厅，吸引人的旅游地点等信息以创建一个旅行网站。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/tripadvisor.jpg?lk3s=cd508e2b&x-expires=1710077841&x-signature=fhTKVu1xHJwxsok2RrwkoztfGHw%3D",
    "id": "7267464834122350653",
    "name": "猫途鹰",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7281192623887548473": {
    "description": "使用头条的搜索功能来阅读或搜索URL链接。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633902722148439_ZnnUQFtsC3.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=QCFsvlZkr1odVy5zR4D4TIyBjMI%3D",
    "id": "7281192623887548473",
    "name": "头条搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7281560856729501753": {
    "description": "回答用户关于代表URL的图片的问题。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633870903670062_nZPstQdbIb.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=eoOY1YZiVzjGf6Iq4cZSILv4NY4%3D",
    "id": "7281560856729501753",
    "name": "图片理解",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288584252030189623": {
    "description": "Bing 图像搜索API允许用户在全球范围内查找图片。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2175268956156697_1709192841685149969_qPefr5tCsS.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=oCq8%2B6SumGEzD%2FVVs%2F9D2EpN43w%3D",
    "id": "7288584252030189623",
    "name": "必应图片搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710077841&x-signature=1vUZpA68eJQ85D6mrx1vkI7rMFQ%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7301970294808494089": {
    "description": "持续更新，了解最新的头条新闻和新闻文章。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/news.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=tFU8hKsM4OCgTBjRRKusCG%2Bpre4%3D",
    "id": "7301970294808494089",
    "name": "头条新闻",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378776128307212": {
    "description": "当你需要查询外汇走势的时候可以使用此插件查询",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621114291895125_rX5vUUQGBU.jpeg?lk3s=cd508e2b&x-expires=1710077841&x-signature=ST4g5lEWy2mL6RA1ufruQoLSM5Q%3D",
    "id": "7303378776128307212",
    "name": "外汇走势",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378823247052812": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_plugin_icon.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=j6lf%2BRB63tkuDiLgQTXK6Gbhj2I%3D",
    "id": "7303378823247052812",
    "name": "LinkReaderPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7309691061943795763": {
    "description": "提供来自世界银行的各种类型的开放数据。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2500753137085275_1701919502403840876_7SxIdVgoit.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=WVA%2FkPsgk9UkhrPS0FUMrF8OSng%3D",
    "id": "7309691061943795763",
    "name": "世界银行",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7310488826684686386": {
    "description": "该插件提供中国证券市场（上海证券交易所和深圳证券交易所）的数据，包括上市公司基本信息、证券价格等。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2175268956156697_1706671249066193822_esuuXB5oFC.jpeg?lk3s=cd508e2b&x-expires=1710077841&x-signature=PiZzKtWCOBxiEVgY8l4F9nh6YIk%3D",
    "id": "7310488826684686386",
    "name": "国内股票",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7312642648354095155": {
    "description": "Food Master提供食物搜索功能。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/143398405153839_1706674514856708119_gXQ3qhsvxq.jpeg?lk3s=cd508e2b&x-expires=1710077841&x-signature=ByTvhvmuZ75xQ1qEW2E3Rmipt7c%3D",
    "id": "7312642648354095155",
    "name": "食物大师",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7319849872859922483": {
    "description": "一个超棒的表情搜索和消息处理插件 # 提供的主要功能： ## EmojiMessage: 将用户输入转换为表情，并推荐可能需要的表情。 ## EmojiTranslation: 将用户输入转换为表情。 ## emojiSearch: 用用户输入搜寻表情包。 ## emojiKitchen: 将两个表情合并为一个表情。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/811914279529784_1704285420067450438_3EpBXpxSr8.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=5P7lqR3rqtDt%2BuW5nJ85mJm5Akk%3D",
    "id": "7319849872859922483",
    "name": "Emojesus",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7324206759499841545": {
    "description": "大猫",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=bDWnxUE89kjL%2BImLJvz6VNytS9A%3D",
    "id": "7324206759499841545",
    "name": "TigerNews",
    "plugin_status": 5,
    "plugin_type": 1
  },
  "7324208543966593074": {
    "description": "WebPilot 与网页交互，提取特定信息或处理URL的内容。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1603551973629358_1705300322286341143_iygfyD6y9O.jpeg?lk3s=cd508e2b&x-expires=1710077841&x-signature=mW8InusS5swFzQaKaDJblrIuTtw%3D",
    "id": "7324208543966593074",
    "name": "WebPilot",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7325002728516796450": {
    "description": "如果你想要查询汽车信息，包括二手车、新车、某些车型的信息时可以使用此插件进行查询",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/4330337972264831_1706683598008238434_IJxoF3TQZf.jpeg?lk3s=cd508e2b&x-expires=1710077841&x-signature=98TrNTeK%2FGypG2BopqOb7l8z7X4%3D",
    "id": "7325002728516796450",
    "name": "懂车帝",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7325003032746311714": {
    "description": "提供二手房、新房、租房信息的插件，想要查询某个城市、区域、户型的房产信息时，可以使用此插件",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/4330337972264831_1706683571988866695_GXCREdDvyQ.jpeg?lk3s=cd508e2b&x-expires=1710077841&x-signature=kyqFc8hJCy8uRYMnWGJ24mUMigo%3D",
    "id": "7325003032746311714",
    "name": "幸福里",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326751620975525939": {
    "description": "根据描述搜索中国诗的详细内容",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1705892801734443723_pUUW7XqCUy.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=onu6%2BVjQEY1EpHP4zfrAN5K9ywg%3D",
    "id": "7326751620975525939",
    "name": "中国诗搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326768020376928306": {
    "description": "银行利率查询，可查询指定银行的贷款利率、存款利率、公积金利率",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621093381803813_iYPuSrevdU.jpeg?lk3s=cd508e2b&x-expires=1710077841&x-signature=dgzsZun1YeIuTQ9vqtkrVc70Rc8%3D",
    "id": "7326768020376928306",
    "name": "国内银行利率",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326774526069489701": {
    "description": "天气Plugin。提供省、市、区县的未来40天的天气情况，包括温度、湿度、日夜风向等。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621033925555371_rPUemhsbVg.webp?lk3s=cd508e2b&x-expires=1710077841&x-signature=d2YNWrBG%2FZ3RFMDSt5cS3DApGNs%3D",
    "id": "7326774526069489701",
    "name": "墨迹天气",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7328330821633507355": {
    "description": "帮助用户根据工作经验、教育经历、地理位置、薪水、职位名称、工作性质等条件搜索猎聘上提供的招聘信息",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1964144797163384_1706695203460853457_uxCbXTt7T3.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=XeWVhdiOR3ZdAXwbyGeN5UtOLF4%3D",
    "id": "7328330821633507355",
    "name": "猎聘",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7331296488854929462": {
    "description": "通过接口获取当前北京时间",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=JTwa3F8vuiHZCRRDrZabO5%2F8GbY%3D",
    "id": "7331296488854929462",
    "name": "当前北京时间",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7333066795550769178": {
    "description": "根据填充词和标题生成词云，并获得词云图片链接",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077841&x-signature=bDWnxUE89kjL%2BImLJvz6VNytS9A%3D",
    "id": "7333066795550769178",
    "name": "wordcloud",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7339238184158724133": {
    "description": "查询bilibili内容",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=k94BSuMAYx%2BqID5XVR2lDqewYgM%3D",
    "id": "7339238184158724133",
    "name": "哔哩哔哩",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7339880377953173555": {
    "description": "热榜数据获取（文章榜&作者榜）",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=tjjss43IsoY78qtq5d9QpypM6Bo%3D",
    "id": "7339880377953173555",
    "name": "掘金热榜",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340254693152587812": {
    "description": "通过调用接口随机返回一首古诗词",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/926251375927184_1709036244700397289_yXFiEPu4xT.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=M%2F9Z21RkGfmpl%2BSf2hjZyjXwF9Y%3D",
    "id": "7340254693152587812",
    "name": "今日诗词",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340261121296711715": {
    "description": "获取知乎热榜列表",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/926251375927184_1709037738013817651_0PtcoVZPNv.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=X2O3vuSNUcW1luKQTUo6w0kCjcs%3D",
    "id": "7340261121296711715",
    "name": "知乎热榜",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340845195153506341": {
    "description": "奥秘插件",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=EHSutQl2LVjn7XxR4L46zUgYxC0%3D",
    "id": "7340845195153506341",
    "name": "MysteryPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340908050615681058": {
    "description": "用AI了解时尚潮流",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=k94BSuMAYx%2BqID5XVR2lDqewYgM%3D",
    "id": "7340908050615681058",
    "name": "UOUN潮流时尚资讯平台",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340949847966580788": {
    "description": "搜索搜索搜索结果",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709198064531046871_yCXs3Bcqh3.jpg?lk3s=cd508e2b&x-expires=1710077840&x-signature=bp9oA6lsjE1ZuvvuC%2BFzgGuFRtA%3D",
    "id": "7340949847966580788",
    "name": "搜狗搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7341248175384035328": {
    "description": "提供A股市场的证券信息、交易数据",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=EHSutQl2LVjn7XxR4L46zUgYxC0%3D",
    "id": "7341248175384035328",
    "name": "A股金融数据",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7341300214776774706": {
    "description": "你好！我是一个能为你提供家庭教育相关信息和建议的智能助手。由大湾区亲子教育研究院全面主持。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=k94BSuMAYx%2BqID5XVR2lDqewYgM%3D",
    "id": "7341300214776774706",
    "name": "家庭教育金字塔",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7341616849324539931": {
    "description": "实时榜中榜和今日早报",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=k94BSuMAYx%2BqID5XVR2lDqewYgM%3D",
    "id": "7341616849324539931",
    "name": "今日热榜",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7341999586799697920": {
    "description": "提取各网页标题以及内容(python学霸公众号)",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709443398609500365_CWDB3Vv0Xg.jpg?lk3s=cd508e2b&x-expires=1710077840&x-signature=IZ3HU9JNTotXuEvgxNKrOuslAi0%3D",
    "id": "7341999586799697920",
    "name": "网页解析器",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7342491104861995017": {
    "description": "微信搜索（python学霸公众号）",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709556881315695947_hRsDEvZReW.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=09fVhJXsWeJotTS9e7UF6zGPnzM%3D",
    "id": "7342491104861995017",
    "name": "微信搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7342784322744893451": {
    "description": "全网热搜插件（79个主流网站）",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709625104078319695_xR9q3HNUpt.png?lk3s=cd508e2b&x-expires=1710077840&x-signature=8zlxsy%2FanK9NoukhvBMJJCMB56I%3D",
    "id": "7342784322744893451",
    "name": "全网热搜",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288245311594610745": {
    "description": "回答用户关于图像的问题",
    "id": "7288245311594610745",
    "name": "imgUnderstand",
    "parameters": [
      {
        "description": "用户关于图片的问题",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图像的URL地址，可以从中下载图像的二进制信息",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281560856729501753"
  },
  "7288584252030206007": {
    "description": "必应图像搜索API允许您的用户在全球范围内找到图片。",
    "id": "7288584252030206007",
    "name": "bingImageSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从结果中返回前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": true,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288584252030189623"
  },
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7288904268684378171": {
    "description": "通过文字描述生成图片",
    "id": "7288904268684378171",
    "name": "text2image",
    "parameters": [
      {
        "description": "1代表通用风格，0代表动漫风格",
        "is_required": false,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "要生成的图片数量",
        "is_required": false,
        "name": "nums",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用于图片描述，使用多个短语概括实体",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图片宽度，必须使用512",
        "is_required": false,
        "name": "width",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "图片高度，必须使用512",
        "is_required": false,
        "name": "height",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7288907006981996602": {
    "description": "从url链接获取正文信息",
    "id": "7288907006981996602",
    "name": "browse",
    "parameters": [
      {
        "description": "用户的有关url链接内容的问题",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望的url",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281192623887548473"
  },
  "7288907006982012986": {
    "description": "搜索用户询问的内容",
    "id": "7288907006982012986",
    "name": "search",
    "parameters": [
      {
        "description": "所需链接的数量限制，默认为10。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "搜索的偏移量，默认为0。",
        "is_required": false,
        "name": "cursor",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。",
        "is_required": false,
        "name": "input_query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "上次搜索返回的search_id，没有可为空",
        "is_required": false,
        "name": "search_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281192623887548473"
  },
  "7301970294808510473": {
    "description": "搜索新闻讯息",
    "id": "7301970294808510473",
    "name": "getToutiaoNews",
    "parameters": [
      {
        "description": "搜索新闻的关键词，必须用中文",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7301970294808494089"
  },
  "7303378776128323596": {
    "description": "外汇走势",
    "id": "7303378776128323596",
    "name": "ForexTrendPlugin",
    "parameters": [
      {
        "description": "日期",
        "is_required": false,
        "name": "time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "目标货币",
        "is_required": true,
        "name": "to",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "想要查询的起始货币",
        "is_required": true,
        "name": "from",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378776128307212"
  },
  "7303378823247069196": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "id": "7303378823247069196",
    "name": "LinkReaderPlugin",
    "parameters": [
      {
        "description": "当type为“检索”时，需要检索的query",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "插件使用方式。可以是“全文”或者“检索”",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "网页url、pdf url、抖音视频url、docx url、csv url。",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378823247052812"
  },
  "7309691658592043059": {
    "description": "搜索国家id，国际代码，首都城市，经度，纬度。特殊提示，您可以一次性通过这个工具获取所有国家的国家id。国家id是这个插件的所有其他工具需要使用的参数。",
    "id": "7309691658592043059",
    "name": "search_a_country_basic_info",
    "parameters": [],
    "plugin_id": "7309691061943795763"
  },
  "7309783931220672521": {
    "description": "购买者价格的GDP是经济中所有常住生产者的总价值增加之和，再加上任何产品税收，减去未包含在产品价值中的任何补贴。数据以当前的美元表示。返回的数据单位为1美元。",
    "id": "7309783931220672521",
    "name": "search_gdp_info",
    "parameters": [
      {
        "description": "根据指定的数字获取最新值。对于多国查询，例如'chn;usa'，请考虑指定'mrv'参数。这会将数据限制在最近几年，例如，'mrv=10'将选择最后十年的数据，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "国家ID。可以通过“search_a_country_basic_info”工具获得国家ID。要同时访问多个国家的数据，请使用分号（;）分隔多个国家ID。例如，要获取中国和美国的数据，请输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "指定您想从数据集中获取的页码。根据之前响应中获取的'pages'值，可以递增这个数字来获取后续更多数据的页面。",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "用于确定每页显示的结果数量。默认设置是每页50个结果。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309810157708460059": {
    "description": "总人口是基于人口的事实定义，计算所有居民，无论法律身份或公民身份如何。显示的值是年中估计值。返回的数据单位是1个个体。",
    "id": "7309810157708460059",
    "name": "search_total_population",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309812136618934322": {
    "description": "人均GDP是国内生产总值除以年中人口数。GDP是经济中所有常住生产者的总价值增加之和，再加上任何产品税收，减去未包含在产品价值中的任何补贴。数据以当前的美元表示。返回的数据单位为1美元。",
    "id": "7309812136618934322",
    "name": "search_gdp_per_capita",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309825846993535027": {
    "description": "总失业人数（占劳动力总数的百分比）（国家估计）。失业是指劳动力中没有工作但现有并寻求就业的人口的比例。各国对劳动力和失业的定义不同。",
    "id": "7309825846993535027",
    "name": "search_unemployment",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309830620715384859": {
    "description": "中央政府债务总额（占GDP的百分比）。债务是指在特定日期上政府对他人的所有固定期限合约义务的全部储备。它包括国内外的债务，如货币和货币存款、非股份证券和贷款。",
    "id": "7309830620715384859",
    "name": "search_center_gov_debt_gdp",
    "parameters": [
      {
        "description": "当前页码",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回多少项，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "根据指定的数字获取最新的值。对于多国家查询，例如'chn;usa'，请考虑指定'mrv'参数。这将数据限制在最近几年，例如'mrv=10'选取了最近十年的数据，减少了数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "国家ID。可以通过“search_a_country_basic_info”工具获得国家ID。要同时访问多个国家的数据，请使用分号（;）分隔多个国家ID。例如，要获取中国和美国的数据，请输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309838485937143858": {
    "description": "人口密度（每平方公里土地面积的人口数量）。人口密度是年中人口除以平方公里的土地面积。",
    "id": "7309838485937143858",
    "name": "search_population_density",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7309842075925921818": {
    "description": "最高10%的人持有的收入份额。收入或消费的百分比份额是按十分位数或五分位数划分的人口子组所获得的份额。",
    "id": "7309842075925921818",
    "name": "search_income_share_highest_10",
    "parameters": [
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7310181882015285257": {
    "description": "经常账户余额（国际收支平衡表，当前美元）。经常账户余额是货物和服务净出口、初级收入净额和二次收入净额的总和。数据以当前美元计价。返回的数据单位是1美元。",
    "id": "7310181882015285257",
    "name": "search_current_account_balance",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7310184062981963813": {
    "description": "外国直接投资，净流入（国际收支平衡表，当前美元）。外国直接投资是指报告经济体中的直接投资股权流入。它是股本、利润再投资及其他资本的总和。返回的数据单位是1美元。",
    "id": "7310184062981963813",
    "name": "search_foreign_direct_invest",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7310185115920138250": {
    "description": "消费者价格指数（2010年=100）。消费者价格指数反映的是平均消费者获取一篮子可能固定或在指定间隔（如每年）改变的商品和服务的成本变化。通常使用Laspeyres公式计算。数据为期间平均值。",
    "id": "7310185115920138250",
    "name": "search_consumer_price_index",
    "parameters": [
      {
        "description": "国家id。可以从工具\"search_a_country_basic_info\"中获取国家ID。若要同时获取多个国家的数据，可用分号(;)分隔多个国家ID。例如，要同时获取中国和美国的数据，可输入'chn;usa'。",
        "is_required": false,
        "name": "country_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "当前页数",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "每页返回的项目数，最小值为4。",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "基于指定的数字获取最近的值。对于多国家查询，例如 'chn;usa'，可以考虑指定 'mrv' 参数，这会限制数据为近年的，例如，'mrv=10' 就会选择最近的十年，从而减少数据量。",
        "is_required": false,
        "name": "mrv",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7309691061943795763"
  },
  "7310490599059374089": {
    "description": "显示公司基本信息。\n接口说明：根据“股票列表”中获取的股票代码，检索上市公司的公司概况。 包括公司基本信息、概念、发行信息等。",
    "id": "7310490599059374089",
    "name": "company_info",
    "parameters": [
      {
        "description": "6位数字组成的股票代码，前3位表示股票的类型和上市地点",
        "is_required": true,
        "name": "stock_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7310488826684686386"
  },
  "7310492663927717938": {
    "description": "公司最近的利润情况。\n界面说明：根据“股票榜”中获取的股票代码，获取上市公司过去一年各季度的利润情况。 按截止日期倒序排列。",
    "id": "7310492663927717938",
    "name": "company_recent_benefits",
    "parameters": [
      {
        "description": "6位数字组成的股票代码，前3位表示股票的类型和上市地点",
        "is_required": true,
        "name": "stock_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7310488826684686386"
  },
  "7312642601554067483": {
    "description": "食物热量查询。输入食物名称，输出其热量。",
    "id": "7312642601554067483",
    "name": "food",
    "parameters": [
      {
        "description": "食物的中文名称",
        "is_required": false,
        "name": "food_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7312642648354095155"
  },
  "7312647881704636453": {
    "description": "显示给定公司的季节性盈利能力。\n接口说明：该接口汇总个股盈利情况，支持“Year_Quarter”查询。 年份可以选择1989年至今年，季度可以选择1：第一季度、2：中期报告、3：第三季度、4：年报。 例如，“2021_1”表示2021年第一季度的数据。",
    "id": "7312647881704636453",
    "name": "profitability_of_company",
    "parameters": [
      {
        "description": "6位数字组成的股票代码，前3位表示股票的类型和上市地点",
        "is_required": true,
        "name": "stock_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询年份，格式为YYYY",
        "is_required": false,
        "name": "year",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询季度，值为枚举值[1,2,3,4]",
        "is_required": false,
        "name": "season",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7310488826684686386"
  },
  "7312649170844778505": {
    "description": "公司的季节增长。\n接口说明：该接口汇总了个股的成长能力，支持“Year_Quarter”格式的查询。 年份可以选择1989年至今年，季度可以选择1：第一季度、2：中期报告、3：第三季度、4：年报。 例如“2021_1”表示查询2021年第一季度的数据。",
    "id": "7312649170844778505",
    "name": "season_growth_of_company",
    "parameters": [
      {
        "description": "6位数字组成的股票代码，前3位表示股票的类型和上市地点",
        "is_required": true,
        "name": "stock_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询年份，格式为YYYY",
        "is_required": false,
        "name": "year",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询季度，值为枚举值[1,2,3,4]",
        "is_required": false,
        "name": "season",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7310488826684686386"
  },
  "7312649748429963314": {
    "description": "接口说明：个股偿债能力汇总，支持“年_季度”查询。 年份可以选择1989年至今年，季度可以选择（1：第一季度报告，2：中期报告，3：第三季度报告，4：年报）。 例如“2021_1”表示查询2021年第一季度的数据。",
    "id": "7312649748429963314",
    "name": "season_debt_repay_of_company",
    "parameters": [
      {
        "description": "查询年份，格式为YYYY",
        "is_required": false,
        "name": "year",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询季度，值为枚举值[1,2,3,4]",
        "is_required": false,
        "name": "season",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "6位数字组成的股票代码，前3位表示股票的类型和上市地点",
        "is_required": true,
        "name": "stock_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7310488826684686386"
  },
  "7312650346944462898": {
    "description": "接口说明：个股操作能力汇总，支持按“年_季度”查询。 年份可以选择1989年至今年，季度可以选择1：第一季度、2：中期报告、3：第三季度、4：年报。 例如，“2021_1”表示2021年第一季度的数据。",
    "id": "7312650346944462898",
    "name": "season_operate_of_company",
    "parameters": [
      {
        "description": "查询季度，值为枚举值[1,2,3,4]",
        "is_required": false,
        "name": "season",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "6位数字组成的股票代码，前3位表示股票的类型和上市地点",
        "is_required": true,
        "name": "stock_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询年份，格式为YYYY",
        "is_required": false,
        "name": "year",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7310488826684686386"
  },
  "7314602509123960870": {
    "description": "搜索适合输入热量的食物。",
    "id": "7314602509123960870",
    "name": "calories",
    "parameters": [
      {
        "description": "食物的卡路里值",
        "is_required": false,
        "name": "calories_value",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7312642648354095155"
  },
  "7319850092364693555": {
    "description": "这用于处理用户输入的信息，它将用户输入的信息转换为表情符号，同时在当前消息状态下生成表情符号，并推荐可能需要的表情符号。",
    "id": "7319850092364693555",
    "name": "EmojiMessage",
    "parameters": [
      {
        "description": "用户发送的所有消息或需要为表情符号生成的部分文本。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319850933704507401": {
    "description": "将用户输入的信息翻译成表情符号。",
    "id": "7319850933704507401",
    "name": "EmojiTranslation",
    "parameters": [
      {
        "description": "用户发送的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851399809024010": {
    "description": "根据用户当前的消息搜索对应的表情符号。",
    "id": "7319851399809024010",
    "name": "EmojiSearch",
    "parameters": [
      {
        "description": "用户需要搜索的消息。",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "页数，如果没有指定，则输入默认值0。",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7319851795084525618": {
    "description": " 将用户发送的两个emoji组合成一个emoji。",
    "id": "7319851795084525618",
    "name": "EmojiKitchen",
    "parameters": [
      {
        "description": "用户发送的第一个表情符号。",
        "is_required": false,
        "name": "firstEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户发送的第二个表情符号。",
        "is_required": false,
        "name": "secondEmoji",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7319849872859922483"
  },
  "7324208543966609458": {
    "description": "WebPilot 进行互联网搜索、分析以及数据生成。\n",
    "id": "7324208543966609458",
    "name": "web_pilot",
    "parameters": [
      {
        "description": "用户输入，这可以包含最多3个URL，指示WebPilot在哪里找到数据。或者如果没有提供URL，WebPilot将自行查找数据。",
        "is_required": true,
        "name": "content",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7324208543966593074"
  },
  "7324251907353051145": {
    "description": "养老虎",
    "id": "7324251907353051145",
    "name": "test_func",
    "parameters": [
      {
        "description": "test",
        "is_required": true,
        "name": "test",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7324206759499841545"
  },
  "7325002728516812834": {
    "description": "当你查询二手车的售卖信息时候可以使用此工具，可以获得二手车的价格、二手车车况图片等信息",
    "id": "7325002728516812834",
    "name": "SecondHandCar",
    "parameters": [
      {
        "description": "期望查询的汽车品牌，如宝马、奥迪",
        "is_required": false,
        "name": "brand",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询二手车的城市",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的二手车类型、如中型suv、紧凑型轿车等",
        "is_required": false,
        "name": "grade",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询二手车的价格范围",
        "is_required": false,
        "name": "price_tag",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的车系，如宝马1系、奥迪a4等",
        "is_required": false,
        "name": "series",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325002728516796450"
  },
  "7325003032746328098": {
    "description": "通过此工具获取租房的信息，包括房子所在的区域，小区名称，房子图片，租房的价格",
    "id": "7325003032746328098",
    "name": "HouseRenting",
    "parameters": [
      {
        "description": "期望查询的区域、如梅溪湖、三里屯",
        "is_required": false,
        "name": "region",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的城市",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的行政区、如海淀、昌平",
        "is_required": false,
        "name": "district",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的房间布局，如1居、2居、3居等",
        "is_required": false,
        "name": "house_layout",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的小区名称",
        "is_required": false,
        "name": "house_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325003032746311714"
  },
  "7325696997799919666": {
    "description": "如果你想买新房，可以先用这个工具获取新房的信息，输入想要的户型、区域、城市、小区名称等，可以获取新房的具体信息，包括房子图片，价格，每平米价格等",
    "id": "7325696997799919666",
    "name": "NewHouse",
    "parameters": [
      {
        "description": "期望查询的城市",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的行政区，如海淀、朝阳",
        "is_required": false,
        "name": "district",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的房间布局",
        "is_required": false,
        "name": "house_layout",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的小区名称",
        "is_required": false,
        "name": "house_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的区域，如三里屯，十里河",
        "is_required": false,
        "name": "region",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325003032746311714"
  },
  "7325698959328968713": {
    "description": "如果想要购买二手房或者查询二手房信息的时候可以使用此工具，输入二手房的城市、户型、小区名称等，可以获取二手房所在的区域，房子图片，二手房总价，每平米价格等信息",
    "id": "7325698959328968713",
    "name": "SecondHandHouse",
    "parameters": [
      {
        "description": "期望查询的区域，如三里屯、十里河",
        "is_required": false,
        "name": "region",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的城市",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的行政区，如海淀、朝阳",
        "is_required": false,
        "name": "district",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的房子结构，如1居、2居等",
        "is_required": false,
        "name": "house_layout",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的小区名称",
        "is_required": false,
        "name": "house_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325003032746311714"
  },
  "7325702773411004425": {
    "description": "当你需要查询新车信息或者查询某个特定车系（如宝马3系，奔驰e级）信息的时候可以使用此工具，可以获得新车价格，车辆结构，车辆生产年份，售卖链接等信息",
    "id": "7325702773411004425",
    "name": "CarSeries",
    "parameters": [
      {
        "description": "期望查询的车系，如宝马3系、奔驰e级",
        "is_required": true,
        "name": "series",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325002728516796450"
  },
  "7326751620975542323": {
    "description": "根据给定条件搜索中国诗",
    "id": "7326751620975542323",
    "name": "search",
    "parameters": [
      {
        "description": "排除的诗词列表",
        "is_required": false,
        "name": "excluded",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "在古代和现代中文中的标签，最多10项。",
        "is_required": false,
        "name": "tags",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      },
      {
        "description": "中国诗词的标题",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "中国诗的作者",
        "is_required": false,
        "name": "author",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "返回的诗数量, 小于10",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326751620975525939"
  },
  "7326768020376944690": {
    "description": "银行利率查询，可查询指定银行的贷款利率、存款利率、公积金利率",
    "id": "7326768020376944690",
    "name": "BankInterestRate",
    "parameters": [
      {
        "description": "银行名。比如农业银行、工商银行、招商银行、中国银行",
        "is_required": true,
        "name": "bank",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询日期。比如：2023/01/02",
        "is_required": false,
        "name": "time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "利率类型。枚举值：存款利率、商业贷款利率、公积金贷款利率",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326768020376928306"
  },
  "7326770499395239946": {
    "description": "获取指定日期的天气",
    "id": "7326770499395239946",
    "name": "DayWeather",
    "parameters": [
      {
        "description": "区/县/镇",
        "is_required": false,
        "name": "towns",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "乡/村",
        "is_required": false,
        "name": "villages",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "市名，包括直辖市，比如：北京市、天津市、上海市、重庆市",
        "is_required": false,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待查询结束日期",
        "is_required": false,
        "name": "end_time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "省份名，不要包括直辖市(比如：北京、北京市、北京省、天津市、上海市、重庆市)",
        "is_required": false,
        "name": "province",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待查询开始日期",
        "is_required": false,
        "name": "start_time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326774526069489701"
  },
  "7328330821633523739": {
    "description": "帮助用户搜索工作招聘，基于用户的工作经验、教育经历、地理位置、薪水、职位名称、工作性质等",
    "id": "7328330821633523739",
    "name": "job_recommendation",
    "parameters": [
      {
        "description": "公司位置，如北京",
        "is_required": false,
        "name": "address",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "教育经历，如硕士，博士等。如果用户没提及受教育程度，此项勿填",
        "is_required": false,
        "name": "eduLevel",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "职位名称，如java开发",
        "is_required": false,
        "name": "jobName",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "薪水上限，必须使用数字来代表，比如：100000",
        "is_required": false,
        "name": "salaryCap",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "薪水下限，必须使用数字来代表，比如：50000",
        "is_required": false,
        "name": "salaryFloor",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "公司性质，填国企、私企",
        "is_required": false,
        "name": "compNature",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "公司名称",
        "is_required": false,
        "name": "companyName",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "薪水类别，只能填“月薪”或者“年薪”。",
        "is_required": false,
        "name": "salaryKind",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "工作经历，填具体年限，如2年以上",
        "is_required": false,
        "name": "workExperience",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7328330821633507355"
  },
  "7329419680601636873": {
    "description": "根据用户的描述生成多种风格的图片\n",
    "id": "7329419680601636873",
    "name": "ImageToolPro",
    "parameters": [
      {
        "description": "图片的链接，在model_type为2的情况下需要传入",
        "is_required": false,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成图片的类型：0代表通用风格、1代表卡通风格、3代表像素贴纸风格、2根据用户输入的图片进行生成",
        "is_required": true,
        "name": "model_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "对于要生成的图片的描述",
        "is_required": true,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7330147114862821386": {
    "description": "根据城市名称、入住日期和退房日期搜索酒店。",
    "id": "7330147114862821386",
    "name": "SearchHotels",
    "parameters": [
      {
        "description": "城市名，必须提取其中的城市名传入",
        "is_required": true,
        "name": "cityName",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "入住日期",
        "is_required": false,
        "name": "checkIn",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "离店日期",
        "is_required": false,
        "name": "checkOut",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7267464834122350653"
  },
  "7330147114862837770": {
    "description": "根据出发地、目的地、日期、行程类型、排序顺序、成人数量、老年人数量和服务等级搜索航班。",
    "id": "7330147114862837770",
    "name": "SearchFlights",
    "parameters": [
      {
        "description": "出发或旅行日期。格式：YYYY-MM-DD",
        "is_required": true,
        "name": "date",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "行程类型，单程为ONE_WAY，往返为ROUND_TRIP，默认为ONE_WAY",
        "is_required": false,
        "name": "itineraryType",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "成人人数（年龄在 18-64 岁之间）。 默认值：1",
        "is_required": false,
        "name": "numAdults",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "起点城市，必须提取其中的城市名传入",
        "is_required": true,
        "name": "sourceCity",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "旅客舱位。输入为ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST. 默认为 ECONOMY",
        "is_required": false,
        "name": "classOfService",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "返回日期。格式：YYYY-MM-DD",
        "is_required": false,
        "name": "returnDate",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "将 sortOrder 传递为 ML_BEST_VALUE、DURATION、PRICE、EARLIEST_OUTBOUND_DEPARTURE、EARLIEST_OUTBOUND_ARRIVAL、LATEST_OUTBOUND_DEPARTURE、LATEST OUTBOUND_ARRIVAL。 默认值：ML_BEST_VALUE。",
        "is_required": false,
        "name": "sortOrder",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "老年人数量（65 岁及以上）。 默认值：0",
        "is_required": false,
        "name": "numSeniors",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "终点城市，必须提取其中的城市名传入",
        "is_required": true,
        "name": "destinationCity",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7267464834122350653"
  },
  "7331296931085336630": {
    "description": "通过苏宁易购接口获取当前北京时间戳",
    "id": "7331296931085336630",
    "name": "getBeijingTimestamp",
    "parameters": [],
    "plugin_id": "7331296488854929462"
  },
  "7332032784040525863": {
    "description": "提供新春萌宠图片生成，当用户上传宠物图片或者提供图片链接时，可以用此工具生成新的新春萌宠图片",
    "id": "7332032784040525863",
    "name": "new_year_pets_image",
    "parameters": [
      {
        "description": "图片链接。该字段是必传的",
        "is_required": true,
        "name": "image_url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "生成的图片的类型模版。宠物礼盒:1 , 新年工笔画:2, 新年唐装:3, 东北大花:4, 情人玫瑰:5, 天使丘比特:6, 恭喜发财:7",
        "is_required": false,
        "name": "model",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "-1代表随机生成。默认29",
        "is_required": false,
        "name": "seed",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "生成的图片质量。0.3:低, 0.5:中, 0.7:高",
        "is_required": false,
        "name": "strength",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7257418203524284472"
  },
  "7333067102099701810": {
    "description": "根据拜年祝福语和标题，生成拜年词云并获得图片链接",
    "id": "7333067102099701810",
    "name": "generate_new_year_wordcloud",
    "parameters": [
      {
        "description": "用于词云填充词的拜年祝福短语，以逗号连接成字符串",
        "is_required": true,
        "name": "fillingWords",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "拜年标题（可选）",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7333066795550769178"
  },
  "7337593919590514751": {
    "description": "根据情人节祝福语和标题，生成情人节词云并获得图片链接",
    "id": "7337593919590514751",
    "name": "generate_valentine_wordcloud",
    "parameters": [
      {
        "description": "用于词云填充词的情人节祝福短语，以逗号连接成字符串",
        "is_required": true,
        "name": "fillingWords",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "情人节词云标题（可选）",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7333066795550769178"
  },
  "7337594758040223756": {
    "description": "根据祝福语和标题，生成无主题的词云并获得图片链接",
    "id": "7337594758040223756",
    "name": "generate_common_wordcloud",
    "parameters": [
      {
        "description": "词云标题（可选）",
        "is_required": false,
        "name": "title",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用于词云填充词的祝福短语，以逗号连接成字符串",
        "is_required": true,
        "name": "fillingWords",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7333066795550769178"
  },
  "7339238615685300274": {
    "description": "查询哔哩哔哩的数据",
    "id": "7339238615685300274",
    "name": "search",
    "parameters": [
      {
        "description": "查询数量，默认为 3",
        "is_required": true,
        "name": "page_size",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "排序方式（default：综合排序；pubdate：按发布日期倒序排序、、、、、、）， 默认为favorites",
        "is_required": true,
        "name": "order",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索类型，例如：video， bili_user（用户），article（专栏），默认为video",
        "is_required": true,
        "name": "search_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "查询关键词",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索结果分页选择，默认为 1",
        "is_required": true,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      }
    ],
    "plugin_id": "7339238184158724133"
  },
  "7339917253590335522": {
    "description": "掘金文章榜&文章收藏榜",
    "id": "7339917253590335522",
    "name": "article_rank",
    "parameters": [
      {
        "description": "分类（默认综合：1）",
        "is_required": true,
        "name": "category_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "类别（热榜:hot,收藏榜: collect）",
        "is_required": true,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7339880377953173555"
  },
  "7339919704531976233": {
    "description": "优质作者榜",
    "id": "7339919704531976233",
    "name": "user_rank",
    "parameters": [
      {
        "description": "类型（默认 1）",
        "is_required": true,
        "name": "item_rank_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "子类型（默认前端 6809637767543259144）",
        "is_required": true,
        "name": "item_sub_rank_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7339880377953173555"
  },
  "7340255333610192905": {
    "description": "每次调用都能够自动获取一首诗词。",
    "id": "7340255333610192905",
    "name": "poetry_generation",
    "parameters": [],
    "plugin_id": "7340254693152587812"
  },
  "7340261376130187318": {
    "description": "获取知乎热榜列表",
    "id": "7340261376130187318",
    "name": "get_hot_list",
    "parameters": [
      {
        "description": "获取数量，默认15条",
        "is_required": false,
        "name": "limit",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340261121296711715"
  },
  "7340468890209861683": {
    "description": "获取推荐列表",
    "id": "7340468890209861683",
    "name": "get_recommend",
    "parameters": [
      {
        "description": "获取数量，默认6",
        "is_required": false,
        "name": "limit",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340261121296711715"
  },
  "7340845243631419418": {
    "description": "奥秘搜索插件",
    "id": "7340845243631419418",
    "name": "SearchPlugin",
    "parameters": [
      {
        "description": "搜索关键词",
        "is_required": true,
        "name": "Query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340845195153506341"
  },
  "7340911346349015078": {
    "description": "用AI重新认识潮流时尚",
    "id": "7340911346349015078",
    "name": "UOUN",
    "parameters": [
      {
        "description": "潮流时尚",
        "is_required": true,
        "name": "UOUN",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340908050615681058"
  },
  "7340950039541481499": {
    "description": "搜狗搜索搜索结果",
    "id": "7340950039541481499",
    "name": "sougou",
    "parameters": [
      {
        "description": "关键词",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340949847966580788"
  },
  "7341248874734092299": {
    "description": "获取A股证券列表",
    "id": "7341248874734092299",
    "name": "stock_list",
    "parameters": [],
    "plugin_id": "7341248175384035328"
  },
  "7341250072577015847": {
    "description": "沪深两市新股日历",
    "id": "7341250072577015847",
    "name": "new_stock_calendar",
    "parameters": [],
    "plugin_id": "7341248175384035328"
  },
  "7341301556891090959": {
    "description": "家庭教育金字塔，成就孩子的未来。\n提供家庭教育中常见问题的解决方案，如孩子的学习问题、行为问题、心理问题等。",
    "id": "7341301556891090959",
    "name": "kidway",
    "parameters": [],
    "plugin_id": "7341300214776774706"
  },
  "7341387554555609098": {
    "description": "获取指数、行业指数以及概念指数（包括基金，债券，美股，外汇，期货，黄金等的代码）",
    "id": "7341387554555609098",
    "name": "query_index",
    "parameters": [],
    "plugin_id": "7341248175384035328"
  },
  "7341390116843192329": {
    "description": "根据指数代码获取对应指数下的证券(指数代码从前面的指数列表接口中获取)",
    "id": "7341390116843192329",
    "name": "query_stock_by_index",
    "parameters": [
      {
        "description": "指数代码",
        "is_required": true,
        "name": "index_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7341248175384035328"
  },
  "7341393156543348771": {
    "description": "查询股票对应的概念指数,指数",
    "id": "7341393156543348771",
    "name": "query_stock_attribute_index",
    "parameters": [
      {
        "description": "股票代码",
        "is_required": true,
        "name": "stock_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7341248175384035328"
  },
  "7341395432683356169": {
    "description": "根据股票代码获取对应上市公司的详情",
    "id": "7341395432683356169",
    "name": "query_company_detail",
    "parameters": [
      {
        "description": "股票代码",
        "is_required": true,
        "name": "stock_code",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7341248175384035328"
  },
  "7341617436443295744": {
    "description": "今日热榜全部榜单每天用户点击最多的 100 条内容。",
    "id": "7341617436443295744",
    "name": "hot",
    "parameters": [],
    "plugin_id": "7341616849324539931"
  },
  "7341618655215599650": {
    "description": "全网精选 20 条国内外新闻简报、历史上的今天以及 +1 条毒鸡汤。",
    "id": "7341618655215599650",
    "name": "daily",
    "parameters": [],
    "plugin_id": "7341616849324539931"
  },
  "7341999891331153932": {
    "description": "网页解析工具，提取网页标题和链接",
    "id": "7341999891331153932",
    "name": "web_parser",
    "parameters": [
      {
        "description": "链接",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7341999586799697920"
  },
  "7342491185350557708": {
    "description": "微信搜索搜索工具",
    "id": "7342491185350557708",
    "name": "wechat_search",
    "parameters": [
      {
        "description": "页数",
        "is_required": false,
        "name": "page_limit",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "关键词",
        "is_required": true,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7342491104861995017"
  },
  "7342785555240943631": {
    "description": "热搜工具，可以获取全网热搜输入0到79获取各网热搜，默认为微博和知乎",
    "id": "7342785555240943631",
    "name": "hot",
    "parameters": [
      {
        "description": "序号，多个使用英文逗号分隔",
        "is_required": true,
        "name": "num",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7342784322744893451"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
