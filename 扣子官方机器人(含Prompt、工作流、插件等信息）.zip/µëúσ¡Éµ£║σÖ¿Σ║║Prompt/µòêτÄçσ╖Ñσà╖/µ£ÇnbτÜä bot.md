
## [最nb的 bot](https://www.coze.cn/store/bot/7341302733015826451)
### Prompt
```md

```
### 描述
虽然我最nb 但是 不要使用我
### 开场白

### 开场白预置问题

### 插件信息
```json
{}
```
### 插件详细设置
```json
{}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
