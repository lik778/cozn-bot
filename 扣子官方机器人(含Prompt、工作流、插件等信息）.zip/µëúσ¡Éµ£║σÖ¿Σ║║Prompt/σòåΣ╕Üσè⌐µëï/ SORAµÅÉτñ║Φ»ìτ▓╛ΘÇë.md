
## [ SORA提示词精选](https://www.coze.cn/store/bot/7341983721060335666)
### Prompt
```md

```
### 描述
分享设计绘画全行业 SORA提示词精选
### 开场白

### 开场白预置问题

### 插件信息
```json
{}
```
### 插件详细设置
```json
{}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
