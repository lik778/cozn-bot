
## [涛哥的BOT](https://www.coze.cn/store/bot/7340988998480920595)
### Prompt
```md

```
### 描述
涛哥工作和生活会用到的应用功能
### 开场白

### 开场白预置问题

### 插件信息
```json
{
  "7281192623887548473": {
    "description": "使用头条的搜索功能来阅读或搜索URL链接。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633902722148439_ZnnUQFtsC3.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=V0c5OWUIS7vfBuNwLbkARdC0JyA%3D",
    "id": "7281192623887548473",
    "name": "头条搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7281560856729501753": {
    "description": "回答用户关于代表URL的图片的问题。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/847077809337655_1706633870903670062_nZPstQdbIb.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=T7scVUw%2Fzq9Qxizk1Elg9ZT0Stk%3D",
    "id": "7281560856729501753",
    "name": "图片理解",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288584252030189623": {
    "description": "Bing 图像搜索API允许用户在全球范围内查找图片。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2175268956156697_1709192841685149969_qPefr5tCsS.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=%2Bk%2FjdWZo1ctRB3c6BRJAmkS0rt8%3D",
    "id": "7288584252030189623",
    "name": "必应图片搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7288585141298102332": {
    "description": "从Bing搜索任何信息和网页URL。",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/600804143405523_1697519094174345728.jpeg?lk3s=cd508e2b&x-expires=1710148840&x-signature=ITZhL0ucVLOjdmZi%2F9oz5aagEdw%3D",
    "id": "7288585141298102332",
    "name": "必应搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7301970294808494089": {
    "description": "持续更新，了解最新的头条新闻和新闻文章。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/news.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=yGb2%2BPxgX%2BQTsHZzT9iO0xRBOu0%3D",
    "id": "7301970294808494089",
    "name": "头条新闻",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7303378823247052812": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_plugin_icon.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=f5pwWTDzA%2BSqJep5tKO3R9ltQH8%3D",
    "id": "7303378823247052812",
    "name": "LinkReaderPlugin",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7312638848524091418": {
    "description": "给新生儿起名",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1814656427232840_1702623434527914058_bhB4UTugPP.jpeg?lk3s=cd508e2b&x-expires=1710148840&x-signature=wlMWKqh0QfY7rRA6i7rmFDmfAwA%3D",
    "id": "7312638848524091418",
    "name": "起名",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7312642648354095155": {
    "description": "Food Master提供食物搜索功能。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/143398405153839_1706674514856708119_gXQ3qhsvxq.jpeg?lk3s=cd508e2b&x-expires=1710148840&x-signature=bGNGjI0aR%2FuLSuAbtzEeGekrrxI%3D",
    "id": "7312642648354095155",
    "name": "食物大师",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7320064854835118106": {
    "description": "快递查询",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/4092809514331888_1704335705097682457_Wvpsx00xu5.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=amkWgojxe00xfAtk5g9UfiphiIA%3D",
    "id": "7320064854835118106",
    "name": "快递查询助手",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7322789345591787570": {
    "description": "用AI生成音乐",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/987825106064111_1704969834027056593_HwPqV0bq45.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=0nYoit4h74TAP8oFG3OBaqn2GVo%3D",
    "id": "7322789345591787570",
    "name": "AI乐队",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7325002728516796450": {
    "description": "如果你想要查询汽车信息，包括二手车、新车、某些车型的信息时可以使用此插件进行查询",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/4330337972264831_1706683598008238434_IJxoF3TQZf.jpeg?lk3s=cd508e2b&x-expires=1710148840&x-signature=6qCgVU8%2BloTSRd5XoVBrgRRVMFQ%3D",
    "id": "7325002728516796450",
    "name": "懂车帝",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7326774526069489701": {
    "description": "天气Plugin。提供省、市、区县的未来40天的天气情况，包括温度、湿度、日夜风向等。",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/3503520560195028_1706621033925555371_rPUemhsbVg.webp?lk3s=cd508e2b&x-expires=1710148840&x-signature=3Dol06uTnkFAdpgHak1HdObMs9c%3D",
    "id": "7326774526069489701",
    "name": "墨迹天气",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7327989061900156955": {
    "description": "基于百度地图的地图插件为用户提供两个主要功能：\n\n周边搜索：用户可以轻松搜索附近的餐厅、娱乐场所以及各种其他餐饮和休闲点，让他们快速找到周围的服务和娱乐选择。我们要求用户提供一个地址和他们正在寻找的地点类型的关键词，比如餐厅、银行、医院等。\n\n路线推荐：提供高效的路线规划和建议，帮助用户快速找到最佳出行路线，节省时间和精力。用户需要提供出发地和目的地的详细信息，以便系统能够规划最佳路线。\n\n如果可能的话，用户还可以提供额外的信息，比如搜索半径（默认为3000米）、出行方式（步行、骑行、驾车或公共交通）以及旅行时间等，以便插件能够提供更加个性化和精确的服务。",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=tyQOEXpV73ygzoOjYFitQhsIV9Q%3D",
    "id": "7327989061900156955",
    "name": "地图精灵",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7328330821633507355": {
    "description": "帮助用户根据工作经验、教育经历、地理位置、薪水、职位名称、工作性质等条件搜索猎聘上提供的招聘信息",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1964144797163384_1706695203460853457_uxCbXTt7T3.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=%2FOFBlUt%2B0pTV%2BwaVl1BkuF2hvJ4%3D",
    "id": "7328330821633507355",
    "name": "猎聘",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7330565391149727754": {
    "description": "这是一个可以根据用户输入或者要记录的 Markdown 字符串和总结的标题来创建云文档的工具。",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/143398405153839_1706869104292117367_eRNBgquZS6.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=4bUDBU1%2Fmrc353Yu%2FWHJl9fT8%2Fg%3D",
    "id": "7330565391149727754",
    "name": "飞书云文档",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7336880488105230376": {
    "description": "在线搜索书籍信息",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2553529766254206_1708329393006626645_JbmGmGcC40.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=%2FXcMFJfuuAVjN%2B28gqzwyGHnadM%3D",
    "id": "7336880488105230376",
    "name": "在线搜书",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7339238184158724133": {
    "description": "查询bilibili内容",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=Mm6ScN34k7rXAAphUoXQnfQXeiE%3D",
    "id": "7339238184158724133",
    "name": "哔哩哔哩",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7339880377953173555": {
    "description": "热榜数据获取（文章榜&作者榜）",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=ff6s4Hg6hGl7nwnwwXduTUNFdgo%3D",
    "id": "7339880377953173555",
    "name": "掘金热榜",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340165450426433536": {
    "description": "获取POI相关信息",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=t4ZsWMsIEt2SWpVG1e8kQd7qKG0%3D",
    "id": "7340165450426433536",
    "name": "百度地图",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340215693666975744": {
    "description": "github apis",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/926251375927184_1709027351624862925_Ttpv9iui29.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=Y33uS5jjm1rYqBvvkv7autj2mng%3D",
    "id": "7340215693666975744",
    "name": "github",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340254693152587812": {
    "description": "通过调用接口随机返回一首古诗词",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/926251375927184_1709036244700397289_yXFiEPu4xT.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=%2BTLdi1z%2F5TyrKqfMDucoddf%2FQkQ%3D",
    "id": "7340254693152587812",
    "name": "今日诗词",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340261121296711715": {
    "description": "获取知乎热榜列表",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/926251375927184_1709037738013817651_0PtcoVZPNv.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=NU3OeZikqymYW6e3nDyGnecW9Hk%3D",
    "id": "7340261121296711715",
    "name": "知乎热榜",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340641593671663656": {
    "description": "调用Stable Difussion生成图片",
    "icon_url": "https://lf6-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/2896570492911642_1709126259471932165_fTxUrwRU7f.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=pcAiV5OM9nC8QSUrW7l3dC9zL5Q%3D",
    "id": "7340641593671663656",
    "name": "SD图片生成",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340913182954962971": {
    "description": "提供一些杰哥收集到的接口API",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/1049378022229548_1709189476019444631_UTctgVvwhR.jpeg?lk3s=cd508e2b&x-expires=1710148840&x-signature=iQwf2fGXQV2O6H0FgwtZO8J%2FLO4%3D",
    "id": "7340913182954962971",
    "name": "杰哥的API工具箱",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340949847966580788": {
    "description": "搜索搜索搜索结果",
    "icon_url": "https://lf26-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709198064531046871_yCXs3Bcqh3.jpg?lk3s=cd508e2b&x-expires=1710148840&x-signature=Eodliyw9Fv2QJja2f%2FI8fJfSzQE%3D",
    "id": "7340949847966580788",
    "name": "搜狗搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340960876062703657": {
    "description": "百度搜索搜索结果（python学霸公众号）",
    "icon_url": "https://lf9-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/275321114075152_1709200618064416775_cwppt7ucnw.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=43oq2%2BUOP0ypv3jUCmX16Pon8wU%3D",
    "id": "7340960876062703657",
    "name": "百度搜索",
    "plugin_status": 4,
    "plugin_type": 1
  },
  "7340982155537039386": {
    "description": "根据关键词查询图片（python学霸）",
    "icon_url": "https://lf3-appstore-sign.oceancloudapi.com/ocean-cloud-tos/plugin_icon/default_icon.png?lk3s=cd508e2b&x-expires=1710148840&x-signature=t4ZsWMsIEt2SWpVG1e8kQd7qKG0%3D",
    "id": "7340982155537039386",
    "name": "图片搜索",
    "plugin_status": 4,
    "plugin_type": 1
  }
}
```
### 插件详细设置
```json
{
  "7288245311594610745": {
    "description": "回答用户关于图像的问题",
    "id": "7288245311594610745",
    "name": "imgUnderstand",
    "parameters": [
      {
        "description": "用户关于图片的问题",
        "is_required": false,
        "name": "text",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "图像的URL地址，可以从中下载图像的二进制信息",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281560856729501753"
  },
  "7288584252030206007": {
    "description": "必应图像搜索API允许您的用户在全球范围内找到图片。",
    "id": "7288584252030206007",
    "name": "bingImageSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从结果中返回前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": true,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288584252030189623"
  },
  "7288585141298118716": {
    "description": "必应搜索引擎。当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。但是绝对不要在用户想要翻译的时候使用它。",
    "id": "7288585141298118716",
    "name": "bingWebSearch",
    "parameters": [
      {
        "description": "响应中返回的搜索结果数量。默认为10，最大值为50。实际返回结果的数量可能会少于请求的数量。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "从返回结果前要跳过的基于零的偏移量。默认为0。",
        "is_required": false,
        "name": "offset",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "用户的搜索查询词。查询词不能为空。",
        "is_required": false,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7288585141298102332"
  },
  "7288907006981996602": {
    "description": "从url链接获取正文信息",
    "id": "7288907006981996602",
    "name": "browse",
    "parameters": [
      {
        "description": "用户的有关url链接内容的问题",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望的url",
        "is_required": false,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281192623887548473"
  },
  "7288907006982012986": {
    "description": "搜索用户询问的内容",
    "id": "7288907006982012986",
    "name": "search",
    "parameters": [
      {
        "description": "所需链接的数量限制，默认为10。",
        "is_required": false,
        "name": "count",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "搜索的偏移量，默认为0。",
        "is_required": false,
        "name": "cursor",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "当你需要搜索你不知道的信息，比如天气、汇率、时事等，这个工具非常有用。",
        "is_required": false,
        "name": "input_query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "上次搜索返回的search_id，没有可为空",
        "is_required": false,
        "name": "search_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7281192623887548473"
  },
  "7301970294808510473": {
    "description": "搜索新闻讯息",
    "id": "7301970294808510473",
    "name": "getToutiaoNews",
    "parameters": [
      {
        "description": "搜索新闻的关键词，必须用中文",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7301970294808494089"
  },
  "7303378823247069196": {
    "description": "当你需要获取网页、pdf、抖音视频内容时，使用此工具。可以获取url链接下的标题和内容。",
    "id": "7303378823247069196",
    "name": "LinkReaderPlugin",
    "parameters": [
      {
        "description": "当type为“检索”时，需要检索的query",
        "is_required": false,
        "name": "prompt",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "插件使用方式。可以是“全文”或者“检索”",
        "is_required": false,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "网页url、pdf url、抖音视频url、docx url、csv url。",
        "is_required": true,
        "name": "url",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7303378823247052812"
  },
  "7312642601554067483": {
    "description": "食物热量查询。输入食物名称，输出其热量。",
    "id": "7312642601554067483",
    "name": "food",
    "parameters": [
      {
        "description": "食物的中文名称",
        "is_required": false,
        "name": "food_name",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7312642648354095155"
  },
  "7312643416163139621": {
    "description": "根据命运给出一个合适的名字，用户必须输入性别、出生年月日时、姓氏，当用户给的信息不完善的时候，给用户返回固定的话术：如果想获得名字，需要给我信息的是：我是男性/女性，姓氏，生于xx年xx月xx日xx时。",
    "id": "7312643416163139621",
    "name": "charactor_fate",
    "parameters": [
      {
        "description": "出生日，格式为dd，取值范围为[1,31]，默认值为31",
        "is_required": true,
        "name": "day",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "要被起名的人的性别，取值范围为男或女",
        "is_required": true,
        "name": "gender",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "出生在当天第几个小时，格式为hh，取值范围为[0,24]无用户输入时，默认为00",
        "is_required": true,
        "name": "hour",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "出生月，格式为mm，取值范围为[1,12]，默认值为1",
        "is_required": true,
        "name": "month",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "出生年，格式为yyyy，例如1998，默认值为2024",
        "is_required": true,
        "name": "year",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7312638848524091418"
  },
  "7314602509123960870": {
    "description": "搜索适合输入热量的食物。",
    "id": "7314602509123960870",
    "name": "calories",
    "parameters": [
      {
        "description": "食物的卡路里值",
        "is_required": false,
        "name": "calories_value",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7312642648354095155"
  },
  "7320065776042508326": {
    "description": "获取快递信息。",
    "id": "7320065776042508326",
    "name": "get_express_info",
    "parameters": [
      {
        "description": "快递单号",
        "is_required": false,
        "name": "express_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7320064854835118106"
  },
  "7322789404693790771": {
    "description": "根据歌词生成歌曲",
    "id": "7322789404693790771",
    "name": "lyrics_to_song",
    "parameters": [
      {
        "description": "歌词数组,每一项是一句歌词,一句歌词长度在4-24字之间。",
        "is_required": true,
        "name": "lyrics",
        "sub_parameters": [],
        "sub_type": "string",
        "type": "array"
      }
    ],
    "plugin_id": "7322789345591787570"
  },
  "7325002728516812834": {
    "description": "当你查询二手车的售卖信息时候可以使用此工具，可以获得二手车的价格、二手车车况图片等信息",
    "id": "7325002728516812834",
    "name": "SecondHandCar",
    "parameters": [
      {
        "description": "期望查询的汽车品牌，如宝马、奥迪",
        "is_required": false,
        "name": "brand",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询二手车的城市",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的二手车类型、如中型suv、紧凑型轿车等",
        "is_required": false,
        "name": "grade",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询二手车的价格范围",
        "is_required": false,
        "name": "price_tag",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "期望查询的车系，如宝马1系、奥迪a4等",
        "is_required": false,
        "name": "series",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325002728516796450"
  },
  "7325702773411004425": {
    "description": "当你需要查询新车信息或者查询某个特定车系（如宝马3系，奔驰e级）信息的时候可以使用此工具，可以获得新车价格，车辆结构，车辆生产年份，售卖链接等信息",
    "id": "7325702773411004425",
    "name": "CarSeries",
    "parameters": [
      {
        "description": "期望查询的车系，如宝马3系、奔驰e级",
        "is_required": true,
        "name": "series",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7325002728516796450"
  },
  "7326770499395239946": {
    "description": "获取指定日期的天气",
    "id": "7326770499395239946",
    "name": "DayWeather",
    "parameters": [
      {
        "description": "市名，包括直辖市，比如：北京市、天津市、上海市、重庆市",
        "is_required": false,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待查询结束日期",
        "is_required": false,
        "name": "end_time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "省份名，不要包括直辖市(比如：北京、北京市、北京省、天津市、上海市、重庆市)",
        "is_required": false,
        "name": "province",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待查询开始日期",
        "is_required": false,
        "name": "start_time",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "区/县/镇",
        "is_required": false,
        "name": "towns",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "乡/村",
        "is_required": false,
        "name": "villages",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7326774526069489701"
  },
  "7327989334269820954": {
    "description": "周边搜索：用户可以轻松搜索附近的餐厅、娱乐场所以及各种其他餐饮和休闲点，让他们快速找到周围的服务和娱乐选择。",
    "id": "7327989334269820954",
    "name": "searchLocation",
    "parameters": [
      {
        "description": "用户希望前往的目的地。",
        "is_required": true,
        "name": "address",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户所在的城市、城市区域、县城或村庄，信息越详细越好。",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户想要搜索的场所类型的关键词，例如餐厅、银行、医院等。",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "用户搜索区域的半径，以米为单位计量，默认为3000米。",
        "is_required": false,
        "name": "radius",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7327989061900156955"
  },
  "7327989334269837338": {
    "description": "路线推荐：提供高效的路线规划和建议，帮助用户快速找到最佳出行路线，节省时间和精力。",
    "id": "7327989334269837338",
    "name": "searchDirection",
    "parameters": [
      {
        "description": "用户所在的城市、城市区域、县城或村庄，越详细越好。",
        "is_required": true,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "目的地。",
        "is_required": true,
        "name": "destination",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "出发地。",
        "is_required": true,
        "name": "origin",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7327989061900156955"
  },
  "7328330821633523739": {
    "description": "帮助用户搜索工作招聘，基于用户的工作经验、教育经历、地理位置、薪水、职位名称、工作性质等",
    "id": "7328330821633523739",
    "name": "job_recommendation",
    "parameters": [
      {
        "description": "公司名称",
        "is_required": false,
        "name": "companyName",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "薪水下限，必须使用数字来代表，比如：50000",
        "is_required": false,
        "name": "salaryFloor",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "工作经历，填具体年限，如2年以上",
        "is_required": false,
        "name": "workExperience",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "薪水上限，必须使用数字来代表，比如：100000",
        "is_required": false,
        "name": "salaryCap",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "薪水类别，只能填“月薪”或者“年薪”。",
        "is_required": false,
        "name": "salaryKind",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "公司位置，如北京",
        "is_required": false,
        "name": "address",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "公司性质，填国企、私企",
        "is_required": false,
        "name": "compNature",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "教育经历，如硕士，博士等。如果用户没提及受教育程度，此项勿填",
        "is_required": false,
        "name": "eduLevel",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "职位名称，如java开发",
        "is_required": false,
        "name": "jobName",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7328330821633507355"
  },
  "7330565779852656650": {
    "description": "这是一个可以根据用户输入或者要记录的 Markdown 字符串和总结的标题来创建云文档的工具。",
    "id": "7330565779852656650",
    "name": "createDocument",
    "parameters": [
      {
        "description": "用户要记录的markdown内容或者普通文本，不能为空，必填",
        "is_required": true,
        "name": "markdownStr",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "待创建文档的标题，如果用户未提供，则根据用户提供的内容总结一个标题",
        "is_required": false,
        "name": "markdownTitle",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7330565391149727754"
  },
  "7336880753411637258": {
    "description": "在线搜索书籍信息，返回结构化的书籍列表信息",
    "id": "7336880753411637258",
    "name": "search_books_online",
    "parameters": [
      {
        "description": "搜索的关键词，可以是书名、作者名、ISBN 等",
        "is_required": true,
        "name": "kw",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7336887801167904778": {
    "description": "根据唯一 id 获取该书籍相关的详细信息",
    "id": "7336887801167904778",
    "name": "get_online_book_info",
    "parameters": [
      {
        "description": "书籍的唯一 id",
        "is_required": true,
        "name": "id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7336880488105230376"
  },
  "7339238615685300274": {
    "description": "查询哔哩哔哩的数据",
    "id": "7339238615685300274",
    "name": "search",
    "parameters": [
      {
        "description": "查询关键词",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索结果分页选择，默认为 1",
        "is_required": true,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "查询数量，默认为 3",
        "is_required": true,
        "name": "page_size",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "排序方式（default：综合排序；pubdate：按发布日期倒序排序、、、、、、）， 默认为favorites",
        "is_required": true,
        "name": "order",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "搜索类型，例如：video， bili_user（用户），article（专栏），默认为video",
        "is_required": true,
        "name": "search_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7339238184158724133"
  },
  "7339917253590335522": {
    "description": "掘金文章榜&文章收藏榜",
    "id": "7339917253590335522",
    "name": "article_rank",
    "parameters": [
      {
        "description": "分类（默认综合：1）",
        "is_required": true,
        "name": "category_id",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "类别（热榜:hot,收藏榜: collect）",
        "is_required": true,
        "name": "type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7339880377953173555"
  },
  "7339919704531976233": {
    "description": "优质作者榜",
    "id": "7339919704531976233",
    "name": "user_rank",
    "parameters": [
      {
        "description": "类型（默认 1）",
        "is_required": true,
        "name": "item_rank_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "number"
      },
      {
        "description": "子类型（默认前端 6809637767543259144）",
        "is_required": true,
        "name": "item_sub_rank_type",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7339880377953173555"
  },
  "7340181680894017555": {
    "description": "根据POI地点名称，获得POI地点对应的经纬度坐标信息",
    "id": "7340181680894017555",
    "name": "getLocationCoordinate",
    "parameters": [
      {
        "description": "POI名称，最多支持84个字节，可以输入两种样式的值（标准的结构化地址信息，如北京市海淀区上地十街十号；支持“*路与*路交叉口”描述方式，如北一环路和阜阳路的交叉路口）",
        "is_required": true,
        "name": "address",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "地址所在的城市名。用于指定上述地址所在的城市",
        "is_required": false,
        "name": "city",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340165450426433536"
  },
  "7340186991037808652": {
    "description": "搜索给定坐标附近的POI信息",
    "id": "7340186991037808652",
    "name": "searchNearbyPoi",
    "parameters": [
      {
        "description": "目标POI的关键字，支持多个关键词，不同关键字间以$符号分隔，最多支持10个关键字检索",
        "is_required": true,
        "name": "query",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "中心点的纬度值,经度值，纬度值在前经度值在后，用半角逗号分隔，lat<纬度值>,lng<经度值>，纬度值取值范围在-90~90，经度值取值范围-180~180，如：39.960247,116.328886",
        "is_required": true,
        "name": "location",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "单次召回POI数量，默认为10条记录，最大返回20条",
        "is_required": false,
        "name": "page_size",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7340165450426433536"
  },
  "7340216947423952950": {
    "description": "搜索github上的仓库",
    "id": "7340216947423952950",
    "name": "searchRepositories",
    "parameters": [
      {
        "description": "确定返回的第一个搜索结果是最大匹配数 (desc) 还是最小匹配数 (asc)。默认：desc",
        "is_required": false,
        "name": "order",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "排序方式，默认: stars, 还可以选择其他项: forks, help-wanted-issues, updated",
        "is_required": false,
        "name": "sort",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "每页查询数量，默认30",
        "is_required": false,
        "name": "per_page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "页数，默认1",
        "is_required": false,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      },
      {
        "description": "该查询包含一个或多个搜索关键字和限定符。限定符允许您将搜索限制在 GitHub 的特定区域。如：keywords+language:js",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340215693666975744"
  },
  "7340226209214775332": {
    "description": "搜索用户",
    "id": "7340226209214775332",
    "name": "searchUsers",
    "parameters": [
      {
        "description": "关键字",
        "is_required": true,
        "name": "q",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340215693666975744"
  },
  "7340255333610192905": {
    "description": "每次调用都能够自动获取一首诗词。",
    "id": "7340255333610192905",
    "name": "poetry_generation",
    "parameters": [],
    "plugin_id": "7340254693152587812"
  },
  "7340261376130187318": {
    "description": "获取知乎热榜列表",
    "id": "7340261376130187318",
    "name": "get_hot_list",
    "parameters": [
      {
        "description": "获取数量，默认15条",
        "is_required": false,
        "name": "limit",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340261121296711715"
  },
  "7340468890209861683": {
    "description": "获取推荐列表",
    "id": "7340468890209861683",
    "name": "get_recommend",
    "parameters": [
      {
        "description": "获取数量，默认6",
        "is_required": false,
        "name": "limit",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340261121296711715"
  },
  "7340643875926769664": {
    "description": "调用SD画图——直接写画图指令就行\nBase Sample：\n猫，椅子，阳台，球\n\n",
    "id": "7340643875926769664",
    "name": "sd_draw",
    "parameters": [
      {
        "description": "描述",
        "is_required": true,
        "name": "p",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340641593671663656"
  },
  "7340914115440951350": {
    "description": "新闻头条",
    "id": "7340914115440951350",
    "name": "news_toutiao",
    "parameters": [
      {
        "description": "第几页",
        "is_required": true,
        "name": "page",
        "sub_parameters": [],
        "sub_type": "",
        "type": "integer"
      }
    ],
    "plugin_id": "7340913182954962971"
  },
  "7340950039541481499": {
    "description": "搜狗搜索搜索结果",
    "id": "7340950039541481499",
    "name": "sougou",
    "parameters": [
      {
        "description": "关键词",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340949847966580788"
  },
  "7340961090039283749": {
    "description": "获取百度搜索搜索结果",
    "id": "7340961090039283749",
    "name": "baidu_sou",
    "parameters": [
      {
        "description": "关键词",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340960876062703657"
  },
  "7340982281881780234": {
    "description": "图片搜索工具",
    "id": "7340982281881780234",
    "name": "image_search",
    "parameters": [
      {
        "description": "页数，可空",
        "is_required": false,
        "name": "page_num",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      },
      {
        "description": "关键词",
        "is_required": true,
        "name": "keyword",
        "sub_parameters": [],
        "sub_type": "",
        "type": "string"
      }
    ],
    "plugin_id": "7340982155537039386"
  }
}
```
### 知识库信息
```json
{
  "auto": true,
  "knowledge_info": [],
  "min_score": 0.5,
  "search_strategy": 0,
  "top_k": 3
}
```
### 工作流设置
```json
[]
```
### 工作流详细设置
```json
{}
```
